

package com.mycompany.polimorfismoexemplo1;

public class PolimorfismoExemplo1 {

    public static void main(String[] args) {
        Carro c = new Ferrari();
        c.acelerar();

        c = new Fusca();
        c.acelerar();
        
    }
}


