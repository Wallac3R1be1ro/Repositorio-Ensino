create database dbEX04;
use dbEX04;

create table tb_Cliente (
idCliente int auto_increment not null primary key,
nomeCliente varchar (60) not null,
sobrenomeCliente varchar (60) not null,
endCliente varchar (120) not null,
saldoCliente numeric (6,2) not null);

select * from tb_Cliente;

insert into tb_Cliente (
nomeCliente, sobrenomeCliente, endCliente, saldoCliente) values
('Paulo', 'Vicente', 'Rua P', 236.80),
('Ana', 'Guedes', 'Rua G', 345.89),
('Lucas', 'Augusto', 'Rua L', 67.79),
('Paulo', 'Freitas', 'Rua F', 432.15);

select ascii ('A') as A;

select distinct length (nomeCliente) as nomeTamanho from tb_Cliente;
select distinct length (nomeCliente) as nomeTamanho from tb_Cliente where idCliente = 1;

select concat(nomeCliente , ' ', sobrenomeCliente) as nomeCompleto from tb_Cliente;

select right (nomeCliente, 3) from tb_Cliente;
select left (nomeCliente, 3) from tb_Cliente;

select reverse (nomeCliente) from tb_Cliente;

select substring(nomeCliente, 1,1) from tb_Cliente;
select round (saldoCliente, -1) as arre_saldo from tb_Cliente;

select round (748.58 , -2);
select round (748.58 , -3);