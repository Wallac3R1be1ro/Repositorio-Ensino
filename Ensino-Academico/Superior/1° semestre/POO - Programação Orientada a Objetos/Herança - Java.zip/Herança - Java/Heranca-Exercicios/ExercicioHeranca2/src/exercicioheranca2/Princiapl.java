/*
    Uma loja que vende roupas possui um sistema capaz de controlar a venda e o 
    estoque. Cada roupa possui um codigo de barras, um tamanho e o nro de 
    exemplares que a loja possui daqela roupa.

    Os clientes da loja sao cadastrados pelo nome e celular para contato de 
    novas peças.

    Faça um diagrama de classe do sistema da loja.
    Agora desenvolva o codigo em Java do sistema e mostrar as seguintes 
    condições:

    1) Quais foram as roupas compradas por um cliente?
    2) Quais sao os clientes que ja compraram uma determinada roupa?
    3) Quantos exemplares possuem de uma determinada roupa?

 */
package exercicioheranca2;

public class Princiapl {

    public static void main(String[] args) {

    }
    
}
