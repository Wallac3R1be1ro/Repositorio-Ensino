/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package revisao2;

/**
 *
 * @author clsma
 */
public class ProfessorMestrado extends ProfessorGraduacao implements InterfaceUniversidade {
    // atributos da classe
    public int AnoTermDoutorado;
    public int qtdeArtigos;
    
    public ProfessorMestrado(String matricula, 
            String nome, double salBruto, int qtdeDisc, 
            int AnoTermDoutorado,int qtdeArtigos) {
        
        super(matricula, nome, salBruto, qtdeDisc);
        this.AnoTermDoutorado = AnoTermDoutorado;
        this.qtdeArtigos = qtdeArtigos;
    }
    
    // sobrescrita da interface
    @Override
    public void calculaSalarioBruto(String tipoProfessor) {
        
        // professor de graduacao
        // = salário bruto – (salário bruto * 0.2) + 
        //  quantidade de disciplinas * 50         
        super.salBruto = super.salBruto - 
               (super.salBruto * 0.2) +
               (super.qtdeDisc * 50);
        
        if (tipoProfessor.equals("Mestrado")) {
            // = salário do professor de graduação + 
            //  quantidade de artigos científicos * 150 
            super.salBruto += this.qtdeArtigos * 150;
        }
        
    }
    
}
