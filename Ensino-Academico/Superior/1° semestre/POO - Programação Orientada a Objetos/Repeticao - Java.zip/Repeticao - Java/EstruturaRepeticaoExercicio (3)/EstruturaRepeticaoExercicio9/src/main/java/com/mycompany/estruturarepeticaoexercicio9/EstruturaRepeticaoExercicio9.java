/*
    Foi feita uma pesquisa entre os habitantes de uma regiao. Foram coletados
    os dados de idade, sexo (M/F) e salario. Faça um programa que calcule e
    mostre:
    
    a) a media dos salarios do grupo
    b) a maior e a menor idade do grupo
    c) a quantidade de mulheres com salario até R$ 2000,00
    d) a idade e o sexo da pessoa que possui o menor salario.

 */

package com.mycompany.estruturarepeticaoexercicio9;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio9 {

    public static void main(String[] args) {
    
    }
}
