/*
    Crie um programa que preenche uma matriz 10 x 20 com numeros inteiros e some
    cada uma das linhas, armazenando o resultado das somas em um vetor. A seguir,
    o programa deverá multiplicar cada elemento da matriz pela soma da linha 
    correspondente e mostrar a matriz resultante.

 */
package matrizexemplo3;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class MatrizExemplo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[][] mat = new int[10][20];
        int[] soma = new int[10];
        int x, y;

        try {
            
            // preenchendo a matriz 10 x 20
            for (x = 0; x < 10; x++) {
                for (y = 0; y < 20; y++) {
                    System.out.print("Digite o valor da matriz: ");
                    mat[x][y] = sc.nextInt();
                }
            }
            
            // somando a matriz
            for (x = 0; x < 10; x++) {
                soma[x] = 0;
                for (y = 0; y < 20; y++) {
                    soma[x] += mat[x][y];
                }
            }
            
            // multiplicando a soma 
            for (x = 0; x < 10; x++) {
                for (y = 0; y < 20; y++) {
                    mat[x][y] *= soma[x];
                }
            }

            // mostrando a matriz
            System.out.println("");            
            for (x = 0; x < 10; x++) {
                for (y = 0; y < 20; y++) {
                    System.out.print(mat[x][y] + " ");
                }
                System.out.println("");
            }

        } catch(InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
