
package revisao2;

public interface InterfaceUniversidade {
    
    // metodos abstratos
    public void calculaSalarioBruto(String tipoProfessor);
    
}
