package com.luanewallace.principal;

import javax.swing.JOptionPane;

public class Principal 
{

	public static void main(String[] args)
	{
		double num1 = Double.parseDouble(JOptionPane.showInputDialog("Digite o primeiro n�mero:"));
		double num2 = Double.parseDouble(JOptionPane.showInputDialog("Digite o segundo n�mero:"));
		
		Calculo calc = new Calculo();
		calc.soma(num1, num2);
		calc.sub(num1, num2);
		calc.multi(num1, num2);
		calc.div(num1, num2);
	}

}
