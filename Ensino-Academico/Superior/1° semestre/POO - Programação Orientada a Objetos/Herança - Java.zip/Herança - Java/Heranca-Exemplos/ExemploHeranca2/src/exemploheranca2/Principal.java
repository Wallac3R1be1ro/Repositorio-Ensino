/*
    Crie a classe Aluno como os seguintes atributos
    String nome
    double n1, n2, n3, n4
    double media
    Implemente os modificadores get e set e também o metodo CalculaMedia

    Crie a classe sala contendo 5 alunos. Pratique a herança dos atributos
    da classe Aluno e atribua as notas de cada aluno e calcule a media e mostre
    a situacao de cada aluno:
    0 - 4 = aluno reprovado
    4 - 6 = aluno exame
    6 - 10= aluno aprovado

 */
package exemploheranca2;

import java.util.Random;
import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Sala sala = new Sala();
        Random rand = new Random();
        
        int i;
        String aux;
        
        aux = "\nDiario do aluno\n\n";
        for (i = 0; i < 5; i++) {
            
            // nome do aluno será um nro aleatorio
            sala.setNome(String.valueOf(rand.nextInt(100)));
            sala.setN1( rand.nextDouble() * 10 );
            sala.setN2( rand.nextDouble() * 10 );
            sala.setN3( rand.nextDouble() * 10 );
            sala.setN4( rand.nextDouble() * 10 );
            sala.CalculaMedia();
            
            // preparando a impressao final
            aux += "Aluno: " + sala.getNome() + "\n";
            aux += "Notas: " + "\n";
            aux += sala.PreparaNotas();
            aux += "Media: " + String.format("%.1f", sala.getMedia()) + "\n";
            aux += "Situaçao: " + sala.situacaoAluno() + "\n\n";

        }
        JOptionPane.showMessageDialog(null, aux);
    }
    
}
