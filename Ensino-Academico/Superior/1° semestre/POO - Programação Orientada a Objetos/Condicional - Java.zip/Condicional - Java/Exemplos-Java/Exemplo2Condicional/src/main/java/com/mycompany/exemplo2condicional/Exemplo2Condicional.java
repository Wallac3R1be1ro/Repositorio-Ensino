/*
 * Um banco concederá um credito especial aos seus clientes, de acordo com o 
   saldo medio no ultimo ano. Faça um programa que receba o saldo medio de um
   cliente e calcule o valor do credito, de acordo com a tabela a seguir. 
   Mostre o saldo medio e o valor do credito.

    SALDO MEDIO                             PERCENTUAL
    Acima de R$ 4000,00                     30% do saldo medio
    R$ 4000,00 a R$ 3000,00                 25% do saldo medio
    R$ 3000,00 a R$ 2000,00                 20% do saldo medio
    Até R$ 2000,00                          10% do saldo medio

 */
package com.mycompany.exemplo2condicional;

/**
 *
 * @author user1
 */
public class Exemplo2Condicional {

    public static void main(String[] args) {
       double saldo, valorCredito;
        
        // atribuindo valor a variavel
        saldo = 2750.13;
        
        // fazendo a verificacao para calcular o valor do credito
        if (saldo > 4000) {
            
            valorCredito = saldo * 0.30;
            
        } else if (saldo > 3000 && saldo <= 4000) {
            
            valorCredito = saldo * 0.25;
            
        } else if (saldo > 2000 && saldo <= 3000) {
            
            valorCredito = saldo * 0.20;
            
        } else {
            
            valorCredito = saldo * 0.10;
        }
        
        // imprimindo o valor do credito
        System.out.println("Valor do credito: " + valorCredito);
        
    }
}
