/*
    Faça um programa que preencha uma matriz 10 x 3 com as notas de dez alunos
    em tres provas. O programa deverá mostrar um relatorio com o numero dos 
    alunos (numero da linha) e a prova em que cada aluno obteve menor nota.
    Ao final do relatorio, deverá mostrar quantos alunos tiveram menor nota em
    cada uma das provas: na prova 1, na prova 2 e na prova 3.
 */
package matrizexemplo1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MatrizExemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double [][] notas = new double[10][3];
        double menor;
        int x, y;
        
        try {
            
            // digitando as notas dos 10 alunos
            for (x = 0; x < 10; x++) {
                for (y = 0; y < 3; y++) {
                    System.out.print("Digite a " +(y+1) + " nota: ");
                    notas[x][y] = sc.nextDouble();
                }
            }
            
            // mostrandos os alunos e suas notas e também a menor nota de cada aluno
            for (x = 0; x < 10; x++) {
                
                menor = notas[x][0];
                System.out.println("\n" + x + " aluno");
                System.out.print("Notas: ");
                
                for (y = 0; y < 3; y++) {
                    System.out.print(" " + notas[x][y]);
                    if (notas[x][y] < menor) {
                        menor = notas[x][y];
                    }
                }
                System.out.println(" - Menor nota: " + menor);
            }
            
            
        } catch(InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
