
package com.mycompany.polimorfismoexemplo2;

public interface Conexao {
    
    public void conectar();
    
}


