
package revisao1;

public class Funcionario {
    public double salBase;
    public String nome;
    public int anoNasc;
    
    // metodo da classe
    public void Exibe() {
        
    }
    
}
