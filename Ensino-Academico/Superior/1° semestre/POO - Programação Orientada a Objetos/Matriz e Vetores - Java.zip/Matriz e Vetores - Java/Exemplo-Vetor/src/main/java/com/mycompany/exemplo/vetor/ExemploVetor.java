/*
 * preencher um vetor com 15 posições e mostre na tela os valores desse vetor;
 */

package com.mycompany.exemplo.vetor;

import java.util.Random;

public class ExemploVetor {

    public static void main(String[] args) {
        int [] vetor = new int[15];
        Random rand = new Random();
        int x,y, pos;
        int v[] = new int[4];
        int nv[] = new int[4];
        pos = 0;
        
        for (x= 0; x < 15; x++){
            vetor [ x ] = rand.nextInt(200);
           
        }
        for (x = 0; x < 15; x++) {
            System.out.println(vetor[x] + ", posição: " + x); 
        }
        for (x = 0; x < 4; x++){
            pos = 0;
            for(y=0; y < 4; y++){
                if(v[x] > v[y]){
                    pos++;
                }
            }
            nv[pos] = v[x];
            System.out.println(vetor[x]);
        }
    }
}
