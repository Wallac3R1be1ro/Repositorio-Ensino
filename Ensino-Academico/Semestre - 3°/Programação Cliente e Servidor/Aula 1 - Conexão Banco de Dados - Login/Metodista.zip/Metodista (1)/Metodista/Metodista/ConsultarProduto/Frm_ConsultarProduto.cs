﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.ConsultarProduto
{
    public partial class Frm_ConsultarProduto : Form
    {
        public Frm_ConsultarProduto()
        {
            InitializeComponent();
        }

        private void Frm_ConsultarProduto_Load(object sender, EventArgs e)
        {
            try
            {
                //Abrindo o banco de dados
                db.ConectarBancoDados();

                //Verificando se o obejeto está sendo usado
                if (reader != null) { reader.Close(); reader = null;  }

                //preparando a query
                sql = "select * from categoria;";

                //Selecionando dados da tabela categoria
                reader = db.SelectDados(sql);

                //verifica se encontrou algum registro no banco de dados
                if (reader.HasRows) // true ou false
                {
                    cbCategoria.Items.Clear();
                    while (reader.Read())
                    {
                        cbCategoria.Items.Add(BinaryReader.GetString(0) + " - " + reader.GetString(1));
                    }
                }
                //Verificando se o objeto está sendo usado
                if (BinaryReader != null) { reader.Close(); reader }
            }
        }
    }
}
