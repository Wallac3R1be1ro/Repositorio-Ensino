/*
    Foi feita uma estatistica em cinco cidades brasileiras para coletar dados
    sobre acidentes de transito. Foram obtidos os seguintes dados:

    a) codigo da cidade;
    b) número de veiculos de passeio (em 2017)
    c) número de acidentes de transito com vitimas (em 2017)
    
    Deseja-se saber:

    a) qual o maior e o menor indice de acidentes de transito e a que cidades
    pertencem;
    b) qual a media de veiculos nas cinco cidades juntas;
    c) qual a media de acidentes de transito nas cidades com menos de 2000
    veiculos de passeio.

 */

package com.mycompany.estruturarepeticaoexercicio3;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio3 {

    public static void main(String[] args) {
   
    }
}
