﻿using System;

namespace Metodista.Login
{
    internal class Frm_EsqueciSenha
    {
        public Frm_EsqueciSenha()
        {
        }

        internal void Close()
        {
            throw new NotImplementedException();
        }

        internal void ShowDialog()
        {
            throw new NotImplementedException();
        }
    }
}