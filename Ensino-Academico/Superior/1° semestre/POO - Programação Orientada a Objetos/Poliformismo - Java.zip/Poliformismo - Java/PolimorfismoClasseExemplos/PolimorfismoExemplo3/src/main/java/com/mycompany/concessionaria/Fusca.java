
package com.mycompany.concessionaria;

public class Fusca implements Carro {
    public double valorCarro;
    
    public Fusca() {
        this.valorCarro = 50000;
    }
    
    @Override
    public double AumentoAnual() {
        this.valorCarro *= 1.10;
        return this.valorCarro;
    }

    @Override
    public void ApresentaCarro() {
        System.out.println("Valor do Fusca: R$ " + String.format("%.2f", this.valorCarro));
    }
    
}
