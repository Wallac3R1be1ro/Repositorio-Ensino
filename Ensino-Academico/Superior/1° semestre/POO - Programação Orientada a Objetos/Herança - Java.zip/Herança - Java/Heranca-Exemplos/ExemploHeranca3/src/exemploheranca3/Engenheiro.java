
package exemploheranca3;

public class Engenheiro extends Funcionario {
    
    public Engenheiro(String nome, String celular, String email) {
        super(nome, celular, email);
    }
    
}
