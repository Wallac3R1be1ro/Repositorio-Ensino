
public class Usuario 
{
	//Atributos
	private int id;
	private String name;
	private String endereco;
	private String email;
	private String escolaridade;
	
	//Metodo Construtor I
	
	public Usuario(int id, String name, String endereco, String email, String escolaridade) {
		super();
		this.id = id;
		this.name = name;
		this.endereco = endereco;
		this.email = email;
		this.escolaridade = escolaridade;
	}
	//Metodo Construtor II
	
	public Usuario()
	{
		
	}
	
	//Getters & Setters
	
	public int getId() {
		return id;
	}	
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEscolaridade() {
		return escolaridade;
	}
	public void setEscolaridade(String escolaridade) {
		this.escolaridade = escolaridade;
	}
	
	
	
}
