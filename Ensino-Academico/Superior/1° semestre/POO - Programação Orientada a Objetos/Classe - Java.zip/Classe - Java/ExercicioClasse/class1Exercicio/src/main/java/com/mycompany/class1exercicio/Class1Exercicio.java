/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.class1exercicio;

import javax.swing.JOptionPane;

/**
 *
 * @author user1
 */
public class Class1Exercicio {

    public static void main(String[] args) {
        CalculaAreaFiguras area = new CalculaAreaFiguras();
        String opc = "-1";
        String menu;
        
        while (!opc.equals("0") ){
            menu = "1-Area do triangulo     \n";
            menu += "2-Area do quadrado     \n";
            menu += "3-Area do circulo      \n";
            menu += "0-Finaliza Programa    \n";
            opc = JOptionPane.showInputDialog(menu);
            
            if (opc.equals("1")){
                area.base = 10;
                area.altura = 8;
                JOptionPane.showMessageDialog(null,
                        "Area triangulo: " + area.calculaArea("triangulo"));
            }else if (opc.equals("2")){
                area.lado = 10;
                JOptionPane.showMessageDialog(null,
                        "Area quadrado: " + area.calculaArea("quadrado"));
            }else if (opc.equals("3")){
                area.raio = 5;
                JOptionPane.showMessageDialog(null,
                        "Area circulo: " + area.calculaArea("circulo"));
            }
        }
    }
}
