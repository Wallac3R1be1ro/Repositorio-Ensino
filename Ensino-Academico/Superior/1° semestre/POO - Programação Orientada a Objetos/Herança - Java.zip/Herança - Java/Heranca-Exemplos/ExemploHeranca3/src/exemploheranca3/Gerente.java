
package exemploheranca3;

public class Gerente extends FuncionarioAutenticavel {
    
    public Gerente(String nome, String celular, String email) {
        super(nome, celular, email);
    }
    
}
