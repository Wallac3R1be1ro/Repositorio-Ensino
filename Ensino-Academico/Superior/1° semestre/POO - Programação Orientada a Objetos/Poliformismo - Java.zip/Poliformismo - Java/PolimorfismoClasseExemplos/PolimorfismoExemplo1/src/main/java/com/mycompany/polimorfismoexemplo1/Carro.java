
package com.mycompany.polimorfismoexemplo1;

public interface Carro {
 
    public void acelerar();

}
