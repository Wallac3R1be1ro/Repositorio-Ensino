import javax.swing.JOptionPane;

public class Operacoes {

	public void CadastroUser(Usuario us) 
	{
		//'Cadastrando' o Usuario
		JOptionPane.showMessageDialog(null,
				"\n ID: " +us.getId()+
				"\n Nome: " +us.getName()+
				"\n End: " +us.getEndereco()+
				"\n Email: " +us.getEmail()+
				"\n Escol.: " +us.getEscolaridade()
				);
	}

}
