﻿using Metodista.AlterarProdutos;
using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.IncluirProdutos
{
    public partial class Frm_AdicionarProduto : Form
    {
        // declarando os atributos da classe
        private ConexaoBancoDados db = new ConexaoBancoDados();
        private MySqlDataReader reader;
        private string sql;

        public Frm_AdicionarProduto()
        {
            InitializeComponent();
        }

        private void Frm_AdicionarProduto_Load(object sender, EventArgs e)
        {

        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_AlterarProduto.ActiveForm.Close();
        }
    }
}
