/*
    Faça um programa que preencha uma matriz 10 x 10 com numeros quaisquer e mostre:

    - a media dos elementos da diagonal principal da matriz

 */
package matrizexercicio7;

public class MatrizExercicio7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
