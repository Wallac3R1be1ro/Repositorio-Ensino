/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicioheranca3;

/**
 *
 * @author walla
 */
public class Mpb extends Musicais {
    private String Banda;
    
    public void InserirDadosMpb(){
        super.setNome("Flores-não-Choram");
        this.Banda = "Os Amantes";
        super.setGenero("Mpd");
    }
    public void MostrarMpb(){
        System.out.println("Nome da Música: " + super.getNome());
        System.out.println("Nome da Banda: " + this.Banda);
        System.out.println("Gênero da Música: " + super.getGenero());
    }
    
    
    
}
