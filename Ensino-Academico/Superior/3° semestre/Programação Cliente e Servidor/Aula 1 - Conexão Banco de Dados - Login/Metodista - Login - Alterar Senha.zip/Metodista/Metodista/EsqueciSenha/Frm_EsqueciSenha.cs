﻿using Metodista.BancoDados;
using Metodista.Login;
using Metodista.Principal;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.EsqueciSenha
{
    public partial class Frm_EsqueciSenha : Form
    {

        public ConexaoBancoDados db = new ConexaoBancoDados();
        public string sql, novasenha, usuario;

        public Frm_EsqueciSenha()
        {
            InitializeComponent();
            this.novasenha = novasenha;
            this.usuario = usuario;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            Frm_EsqueciSenha.ActiveForm.Close();
        }

        private void lblAlterarS_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(tUsuario.Text))
            {
                MessageBox.Show("Digite o usuário");
                tUsuario.Focus();
                return;
            }
            if (String.IsNullOrEmpty(tSenha.Text))
            {
                MessageBox.Show("Digite a nova senha");
                tSenha.Focus();
                return;
            }


            // fazer a query de update do usuario
            try
            {
                // conectando o banco de dados
                db.ConectarBancoDados();

                this.novasenha = tSenha.Text;

                // preparando a query (update)
                sql = "update tab_usuarios set senha = '" + this.novasenha + "' " +
                      " where usuario = '" + this.usuario + "'; ";

                db.UpdateDados(sql);
                MessageBox.Show("Senha alterado com sucesso!!!");


            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro de autenticação " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                return;
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
            }
        }

        private void Frm_EsqueciSenha_Load(object sender, EventArgs e)
        {
            tSenha.Text = this.novasenha;
        }

        private void tUsuario_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
