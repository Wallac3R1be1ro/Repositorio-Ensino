/*
    Elabore um programa que preencha uma matriz 6 x 3, calcule e mostre:

    a) o maior elemento da matriz e sua respectiva posição, ou seja, linha e 
       coluna;

    b) o menor elemento da matriz e sua respectiva posição, ou seja, linha e 
       coluna.

 */
package matrizexercicio3;

public class MatrizExercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
