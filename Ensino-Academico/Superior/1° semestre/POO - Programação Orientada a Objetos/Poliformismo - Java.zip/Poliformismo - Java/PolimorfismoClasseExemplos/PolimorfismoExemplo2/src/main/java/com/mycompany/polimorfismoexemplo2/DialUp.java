
package com.mycompany.polimorfismoexemplo2;

public class DialUp implements Conexao {

    @Override
    public void conectar() {
        System.out.println("Modem discando…");
    }
    
}


