/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.class2exercicio;

/**
 *
 * @author user1
 */
public class Class2Exercicio {

    public static void main(String[] args) {
        Vetor vetor = new Vetor();
        
        vetor.preencherVetor();
        vetor.imprimirOrdemDireta();
        //System.out.println("Hello World!");
    }
}
