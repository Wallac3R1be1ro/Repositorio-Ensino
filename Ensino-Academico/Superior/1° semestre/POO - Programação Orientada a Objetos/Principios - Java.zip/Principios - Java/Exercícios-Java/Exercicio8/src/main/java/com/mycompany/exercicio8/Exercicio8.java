/*
 * Faça um programa que receba o ano de nascimento de uma pessoa e o ano atual,
 * calcule e mostre:
 *
 * a) a idade dessa pessoa;
 * b) quantos anos ela terá em 2050
 *
 */

package com.mycompany.exercicio8;

public class Exercicio8 {

    public static void main(String[] args) {
      String nome ="Wallace";
      //int anoFuturo, idadeAtual, anoNascimento;
     
      for(int cont=0 ; cont > 5 ; cont++){
                System.out.println("contando até 5");
            }
            System.out.println("Fim do Programa");
          
      
      
      /*for(int anoAtual = 2050; anoAtual >= 2003; anoAtual++){
          System.out.println(anoAtual + "Valor");
      }
      
      System.out.println("O jovem " + nome + ", terá em " + anoFuturo + " a idade de: ");*/
    }
}
