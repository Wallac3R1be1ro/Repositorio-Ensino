
package revisao1;

public class Programador extends Funcionario {
    // criando os atributos da classe
    public boolean graduacao;
    public boolean certificadoJava;
    public char sexo;
    
    // construtor da classe
    // aplicando a sobrecarga / polimorfismo
    public Programador() {
        
    }
    public Programador(boolean graduacao, double salBase, boolean certificadoJava, String nome, char sexo, int anoNasc) {
        this.graduacao = graduacao;
        super.salBase = salBase;
        this.certificadoJava = certificadoJava;
        super.nome = nome;
        this.sexo = sexo;
        super.anoNasc = anoNasc;
    }   
    // metodo da classe
    // pratica da sobrescrita
    @Override
    public void Exibe() {
        System.out.println("Dados do profissional Programador\n");
        System.out.println("Nome: " + super.nome);
        System.out.println("Sexo: " + this.sexo);
        System.out.println("Ano Nasc: " + super.anoNasc);
        System.out.println("Salario Base: " + super.salBase);
        
        if (this.graduacao) { // true ou false
            System.out.println("Tem graduacao: " + "Sim");
        } else {
            System.out.println("Tem graduacao: " + "Não");
        }
        
        if (this.certificadoJava) {
            System.out.println("Tem certificado Java: " + "Sim");
        } else {
            System.out.println("Tem certificado Java: " + "Não");
        }

    } 
    public String Exibe(boolean flag) { 
        String aux = "Dados do Programador\n;";
        
        aux += "Nome: "         + super.nome        + "\n;";
        aux += "Sexo: "         + this.sexo         + "\n;";
        aux += "Ano Nasc: "     + super.anoNasc     + "\n;";
        aux += "Salario Base: " + super.salBase     + "\n;";
        if (this.graduacao) { // true ou false
            aux += "Tem graduacao: Sim" + "\n;";
        } else {
            aux += "Tem graduacao: Não" + "\n;";
        }
        if (this.certificadoJava) {
            aux += "Tem certificado Java: Sim" + "\n;";
        } else {
            aux += "Tem certificado Java: Não" + "\n";;
        }
        aux += "Final\n";
        
        return aux;
    }
    
}
