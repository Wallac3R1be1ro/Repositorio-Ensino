/*
    Faça um programa que monte os oito primeiros termos da sequencia de 
    Fibonacci.

    0-1-1-2-3-5-8-13-21-34-55...

 */

package com.mycompany.estruturarepeticaoexercicio5;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio5 {

    public static void main(String[] args) {
      
    }
}
