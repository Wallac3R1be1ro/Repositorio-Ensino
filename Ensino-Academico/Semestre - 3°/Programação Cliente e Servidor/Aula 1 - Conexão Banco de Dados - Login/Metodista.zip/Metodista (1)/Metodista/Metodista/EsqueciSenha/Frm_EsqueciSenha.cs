﻿using Metodista.BancoDados;
using Metodista.Login;
using Metodista.Principal;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.EsqueciSenha
{
    public partial class Frm_EsqueciSenha : Form
    {

        public ConexaoBancoDados db = new ConexaoBancoDados();
        public string sql;        

        public Frm_EsqueciSenha()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            Frm_EsqueciSenha.ActiveForm.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            // verificar se ha algo digitado no usuario

            // verificar se ha algo digitado na senha


            // fazer a query de update do usuario
            try
            {

                // executando o metodo
                db.ConectarBancoDados();

                // preparando a query na tabela do banco de dados
                sql = "usar update";

                // salvar o banco de dados (commit) criar o metodo na classe

                // fechar o banco

                // enviar msg para usuario de Usuario/Senha criada

                // fechar o formulario



            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Erro de autenticação " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
                return;
            }
        }

        private void Frm_EsqueciSenha_Load(object sender, EventArgs e)
        {

        }
    }
}
