<?php
$numeros = ['martelo', 'furadeira', 'serra', 'alicate', 'marreta', 'serrote'];
echo count($numeros);
//Nomes: Wallace, Joyce, Igor
?>