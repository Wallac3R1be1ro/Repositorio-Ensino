/*
    Faça um projeto em Java criando uma classe responsavel que calcule  e mostre
    a area de:
    
    a) um triangulo;
    b) um quadrado;
    c) um circulo

 */
package classeexercicio1;

public class ClasseExercicio1 {

    public static void main(String[] args) {
        
    }
    
}
