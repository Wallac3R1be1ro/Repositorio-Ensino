
package exemploclasse6;

import java.util.Random;

public class Estoque {
    // declarando os atributos da classe
    public double [] preco = new double[10];
    public double [][] qtde = new double[5][10];
    public double qtdeCadaArmazem;
    public double precoProduto;
    public double menor, maior;
    public double custo;
    
    
    // metodos da classe
    public void geraPreco() {
        int i,j;
        
        // gerando os preços dos 10 produtos aleatoriamente
        for (i = 0; i < 10; i++) {
            this.preco[i] = Math.random(); 
        }
        
    }
    public void geraQtdeArmazem() {
        Random rand = new Random();
        int i,j;  
        
        // gerando as quantidades em cada armazem para cada produto
        for (i = 0; i < 5; i++) {
            for (j = 0; j < 10; j++) {
                this.qtde[i][j] = 10 + rand.nextInt(200);
            }
        }
        
    }
    public void qtdeProdutosEstocados() {
        int i, j;
        
        for (i = 0; i < 5; i++) {
            System.out.println("Armazem: (" + i + ") existem estocados");
            for (j = 0; j < 10; j++) {
                System.out.println("Estoque: " + j + " qtde: " + this.qtde[i][j]);
            }
            System.out.println(" ");
        }
        
    }
    public void qtdeProdutosArmazens() {
        int i, j;
        
        for (i = 0; i < 5; i++) {
            this.qtdeCadaArmazem = 0;
            System.out.println("Armazem: (" + i + ") existem: ");
            for (j = 0; j < 10; j++) {
                this.qtdeCadaArmazem += this.qtde[i][j];
            }
            System.out.println(this.qtdeCadaArmazem + " produtos.");
        }
        
    } 
    public void precoMaiorEstoque() {
        int i, j;
        
        this.maior = 0;
        for (i = 0; i < 5; i++) {
            for (j = 0; j < 10; j++) {
                if (this.qtde[i][j] >= this.maior) {
                    this.maior = this.qtde[i][j];
                    this.precoProduto = this.preco[j];   
                }
            }
        }
        System.out.println("\nO preço do produto de maior estoque");
        System.out.println("Preço do produto: R$ " + String.format("%.2f", this.precoProduto));
        System.out.println("Qtde em estoque: " + this.maior);
    }
    public void menorEstoqueArmazenado() {
        int i, j;
        
        this.menor = this.qtde[0][0];
        for (i = 0; i < 5; i++) {
            for (j = 0; j < 10; j++) {
                if (this.qtde[i][j] <= this.menor) {
                    this.menor = this.qtde[i][j];
                }
            }
        }
        System.out.println("\nO menor estoque armazenado");
        System.out.println("Qtde em estoque: " + this.menor);
    }
    public void custoCadaArmazem() {
        int i, j;
        
        System.out.println(" ");
        for (i = 0; i < 5; i++) {
            this.custo = 0;
            System.out.print("Armazem: (" + i + ") custo total R$: ");
            for (j = 0; j < 10; j++) {
                this.custo += this.qtde[i][j] * this.preco[j];
            }
            System.out.println(String.format("%.2f", this.custo));
        }
        
    } 
}
