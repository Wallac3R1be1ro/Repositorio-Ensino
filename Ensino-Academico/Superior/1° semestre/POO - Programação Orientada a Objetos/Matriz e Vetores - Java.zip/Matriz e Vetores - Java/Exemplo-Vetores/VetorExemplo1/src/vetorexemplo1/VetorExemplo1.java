/*

    Faça um programa que preencha um vetor com dez números inteiros, calcule
    e mostre os números superiores a cinquenta e suas respectivas posições.
    O programa deverá mostrar mensagem se não existir nenhum número nessa 
    condição.

 */
package vetorexemplo1;

import java.util.InputMismatchException;
import java.util.Scanner;

public class VetorExemplo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] vet = new int[10];
        int x;
        Scanner sc = new Scanner(System.in);
        
        try {
            // digitando os números pelo usuario
            for (x = 0; x < 10; x++) {
                System.out.print("Digite um nro qq: ");
                vet[x] = sc.nextInt();
            }
            
            // verificando os valores do vetor maior do que 50
            // e mostrando os valores e suas posiçoes
            for (x = 0; x < 10; x++) {
                if ( vet[x] > 50) {
                    System.out.print("Valor do vetor: " + vet[x]);
                    System.out.println(" Posição: " + x);
                }
            }
            
        } catch (InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
