/*
    Faça um programa que receba o receba 10(dez) idades, pesos e alturas,
    calcule e mostre:

    a) a media das idades das dez pessoas;
    b) a quantidade de pessoas com peso superior a 90 quilos e altura inferior
    a 1.5 metro;
    c) a percentagem de pessoas com idade entre 10 e 30 anos entre as pessoas
    que medem mais de 1.9 metro.

 */

package com.mycompany.estruturarepeticaoexercicio6;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio6 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
