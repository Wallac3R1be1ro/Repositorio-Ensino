/*
    Um cliente pode fazer diversos contratos de locacao de carros numa 
    locadora de veiculos. A locadora aluga caminhoes, carros de passeo
    categoria A, B e C e motos. Os contratos diferem em valor e imposto
    segundo o tipo de veiculo locado. Construa um projeto em Java para
    representar as classes e seus relacionamentos. Mostre dados do 
    contrato e valor de locacao de um carro categoriaC.
    
    Dados: as classes sao
    Cliente, Contrato, Veiculo, Caminhao, Carro, Moto, CategoriaA,
    CategoriaB, CategoriaC
 */
package exercicioheranca4;

/**
 *
 * @author clsma
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
