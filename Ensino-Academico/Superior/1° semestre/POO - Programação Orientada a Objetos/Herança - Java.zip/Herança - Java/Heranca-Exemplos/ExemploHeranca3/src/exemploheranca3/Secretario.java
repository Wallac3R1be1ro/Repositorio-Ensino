
package exemploheranca3;

public class Secretario extends Funcionario {
    
    public Secretario(String nome, String celular, String email) {
        super(nome, celular, email);
    }
    
}
