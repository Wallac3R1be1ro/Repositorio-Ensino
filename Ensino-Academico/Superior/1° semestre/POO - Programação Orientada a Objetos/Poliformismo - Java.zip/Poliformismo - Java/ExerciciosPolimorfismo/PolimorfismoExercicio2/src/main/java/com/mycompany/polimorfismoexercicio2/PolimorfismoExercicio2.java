/*
Crie uma classe java Numero que contenha um método que receba dois números 
inteiros e imprima o maior entre eles. Na mesma classe crie o metodo que receba 
um número inteiro e imprima, em ordem decrescente, o valor do número até 0.
Ainda na mesma classe, Crie um método que receba dois números NumA e NumB, nessa 
ordem, e imprima em ordem inversa, isto é, se os dados lidos forem NumA = 5 e 
NumB = 9, por exemplo, devem ser impressos na ordem NumA = 9 e NumB = 5.

Crie a classe filha e modifique o metodo herdado descrescente e mostre os numeros
crescente 

Crie a interface para os metodos da classe.


 */

package com.mycompany.polimorfismoexercicio2;

/**
 *
 * @author clsma
 */
public class PolimorfismoExercicio2 {

    public static void main(String[] args) {
        
    }
}
