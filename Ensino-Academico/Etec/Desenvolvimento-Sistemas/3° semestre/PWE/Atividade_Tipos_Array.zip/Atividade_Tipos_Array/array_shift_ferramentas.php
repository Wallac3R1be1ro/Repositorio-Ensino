<?php
$ferramentas=array('alicate','serrote','marreta','serra');
array_shift($ferramentas);
print_r($ferramentas);

//---------------------------------------

$ferramentas=array('alicate','marreta','serrote','martelo');
array_shift($ferramentas);
print_r($ferramentas);
//Nomes: Wallace, Joyce, Igor

?>