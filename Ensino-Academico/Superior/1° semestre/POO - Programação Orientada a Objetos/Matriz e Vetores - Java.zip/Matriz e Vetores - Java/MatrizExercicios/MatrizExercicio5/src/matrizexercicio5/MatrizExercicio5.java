/*
    Elabore um programa que preencha uma matriz 12 x 4 com os valores das 
    vendas de uma loja, em que cada linha representa um mes do ano e cada coluna
    representa uma semana do mes. O programa deverá calcular e mostrar:

    a) o total vendido em cada mes do ano, mostrando o nome do mes por extenso;
    b) o total vendido em cada semna durante todo o ano;
    c) o total vendido pela loja no ano.

 */
package matrizexercicio5;

public class MatrizExercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
