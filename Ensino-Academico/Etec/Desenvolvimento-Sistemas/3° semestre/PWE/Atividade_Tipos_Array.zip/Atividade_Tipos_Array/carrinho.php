<?php

    $arr = array("Ferramenta" => "Alicate", "qtd" => "1300", "Valor" => "23,50");
    print_r($arr);

    echo "<br><br>";
    echo "Ferramenta: <br>".$arr["Ferramenta"]."<br><br>";
    echo "Quantidade: <br>".$arr["qtd"]."<br><br>";
    echo "Valor: <br>".$arr["Valor"]."<br>";
//Nomes: Wallace, Joyce, Igor
?>