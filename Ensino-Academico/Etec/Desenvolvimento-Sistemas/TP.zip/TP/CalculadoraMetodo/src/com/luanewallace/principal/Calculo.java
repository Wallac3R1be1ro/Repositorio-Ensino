package com.luanewallace.principal;

import javax.swing.JOptionPane;

public class Calculo 
{
	public void soma(double num1, double num2)
	{
		double res = num1 + num2;
		JOptionPane.showMessageDialog(null, num1 + " + " + num2 + " = " + res);
	}
	
	public void sub(double num1, double num2)
	{
		double res = num1 - num2;
		JOptionPane.showMessageDialog(null, num1 + " - " + num2 + " = " + res);
	}
	
	public void multi(double num1, double num2)
	{
		double res = num1 * num2;
		JOptionPane.showMessageDialog(null, num1 + " * " + num2 + " = " + res);
	}
	
	public void div(double num1, double num2)
	{
		double res = num1 / num2;
		JOptionPane.showMessageDialog(null, num1 + " / " + num2 + " = " + res);
	}
}
