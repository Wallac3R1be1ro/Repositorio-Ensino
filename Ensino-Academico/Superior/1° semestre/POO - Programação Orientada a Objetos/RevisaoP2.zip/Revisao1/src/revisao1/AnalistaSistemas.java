
package revisao1;

public class AnalistaSistemas extends Funcionario {
    
}
