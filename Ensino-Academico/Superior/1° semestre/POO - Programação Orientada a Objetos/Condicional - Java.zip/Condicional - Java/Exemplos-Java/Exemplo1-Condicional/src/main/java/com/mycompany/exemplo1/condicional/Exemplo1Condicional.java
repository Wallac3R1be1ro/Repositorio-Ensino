/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.exemplo1.condicional;

/**
 *
 * @author user1
 */
public class Exemplo1Condicional {

    public static void main(String[] args) {
        double sal;
        
        // atribuindo o valor do salario
        sal = 415.00;
        
        // verificando o percentual de aumento de acordo com o salario
        if (sal <= 300) {
            sal = (sal * 1.35);
        } else {
            sal = (sal * 1.15);
        }
        
        // imprimindo o salario com o devido aumento
        System.out.println("Aumento: " + sal);
    }
}
