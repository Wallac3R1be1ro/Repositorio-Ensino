/*
    Faça um programa que leia um vetor com cinquenta posiçoes para numeros
    inteiros positivos e negativos, mostre somente os numeros positivos

 */
package vetorexercicio5;

public class VetorExercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
