/*
    Faça um programa que receba no número de termos e um valor positivo para X,
    calcule e mostre o valor da serie a seguir:

    S = (-X^2/1!) * (X^3/2!) * (-X^4/3!) * (X^5/4!) * -...

 */

package com.mycompany.estruturarepeticaoexercicio4;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio4 {

    public static void main(String[] args) {
        
    }
}
