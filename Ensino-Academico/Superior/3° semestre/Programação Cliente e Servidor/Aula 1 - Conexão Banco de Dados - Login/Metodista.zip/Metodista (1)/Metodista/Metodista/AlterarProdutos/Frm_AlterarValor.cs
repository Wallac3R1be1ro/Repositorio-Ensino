﻿using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.AlterarProdutos
{
    public partial class Frm_AlterarValor : Form
    {
        ConexaoBancoDados db = new ConexaoBancoDados();
        private string valor, codigo;
        private string sql;



        public Frm_AlterarValor(string codigo, string valor)
        {
            InitializeComponent();
            this.valor = valor;
            this.codigo = codigo;
        }

        private void Frm_AlterarValor_Load(object sender, EventArgs e)
        {
            tValor.Text = this.valor;
        }

        private void lblNaoOK_Click(object sender, EventArgs e)
        {
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            //Frm
        }

        private void lblOK_Click(object sender, EventArgs e)
        {

            try
            {
                // conectando o banco de dados
                db.ConectarBancoDados();

                // preparando a query (busca/select)
                sql = "update precoproduto set preco = '" + this.valor + "' " +
                      " where codigo = '" + this.codigo + "'; ";
                db.UpdateDados(sql);
                db.CommitBanco();


            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
