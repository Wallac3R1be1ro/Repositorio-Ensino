/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploheranca1;

/**
 *
 * @author clsma
 */
public class Empregado extends Pessoa {
    // declarando os atributos da classe Empregado
    private int codigoSetor;
    private double salarioBase;
    private double imposto;
    
    // metodo da classe Empregado
    public void calculaSalario() {
        if (codigoSetor == 121) {     // pratica aumento para o setor 121
            this.salarioBase *= 1.20; // aplicando 20% de aumento para o setor
            this.imposto = 8.5;     // 0.85% de imposto
        } else {
            this.salarioBase *= 1.10; // aplicando 10% de aumento demais setores
            this.imposto = 6.5;     // 0.65% de imposto
        }
    }
    
    // metodos get's e set's
    public int getCodigoSetor() {
        return codigoSetor;
    }
    public void setCodigoSetor(int codigoSetor) {
        this.codigoSetor = codigoSetor;
    }
    public double getSalarioBase() {
        return salarioBase;
    }
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    public double getImposto() {
        return imposto;
    }
    public void setImposto(double imposto) {
        this.imposto = imposto;
    }
    
}
