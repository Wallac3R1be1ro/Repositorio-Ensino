/*
    Criar uma classe Conta e fazer 20 transações de saque e deposito, 
    lembrando que, para o saque a classe Conta deve verificar se existe saldo
    suficiente para tal transação. Mostre o saldo atual da conta

 */
package exemploclasse3;

import java.util.Random;

public class ExemploClasse3 {

    public static void main(String[] args) {
        // declarando a classe Conta
        Conta conta = new Conta();
        Random rand = new Random();
        
        // declarando as variaveis primitivas
        int i;
        double valor;
       
        // atribuindo valores aos atributos da classe Conta
        conta.nomeTitular = "Antonio Carlos Silva";
        conta.nroConta = "51.237-8";
        conta.limite = 100.0;
        conta.saldo = 0;
                
        // fazendo as 100 transações
        for (i = 0; i < 20; i++) {
            valor = rand.nextInt(10000); // gerando valores aleatorios
            
            if (valor % 2 == 0) {
                conta.Depositar(valor);
            } else {
                conta.Sacar(valor);
            }
        }

        System.out.println("saldo atual: R$ " + conta.saldo);

    }
    
}
