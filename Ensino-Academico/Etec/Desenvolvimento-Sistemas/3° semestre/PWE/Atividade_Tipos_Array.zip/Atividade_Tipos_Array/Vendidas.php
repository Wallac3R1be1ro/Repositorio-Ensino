<?php

echo "As ferramentas mais vendidas são: " . "<br>";

$ferramentas = array('martelo', 'furadeira', 'serra', 'alicate', 'marreta', 'serrote');
foreach($ferramentas as $ferramentas)
{
    echo "". $ferramentas . "<br>";
}
//Nomes: Wallace, Joyce, Igor
?>