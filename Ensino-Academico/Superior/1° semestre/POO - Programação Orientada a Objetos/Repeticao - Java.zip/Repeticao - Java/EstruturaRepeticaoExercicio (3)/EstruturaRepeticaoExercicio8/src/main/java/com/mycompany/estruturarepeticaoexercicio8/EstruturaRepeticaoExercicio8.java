/*
    Faça um programa que receba a idade, a altura e o peso de 25 pessoas, 
    calcule e mostre:
    
    a) a quantidade de pessoas com idade superior a 50 anos
    b) a media das alturas das pessoas com idade entre 10 e 20 anos
    c) a percentagem de pessoas com peso inferiora 40 quilos entre todas as 
    pessoas analisadas.

 */

package com.mycompany.estruturarepeticaoexercicio8;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio8 {

    public static void main(String[] args) {
        
    }
}
