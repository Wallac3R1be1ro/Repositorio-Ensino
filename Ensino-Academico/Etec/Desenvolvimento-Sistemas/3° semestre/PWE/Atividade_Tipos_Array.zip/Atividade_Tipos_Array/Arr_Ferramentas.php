<?php
$arr=array("martelo","furadeira","serra");
echo "nossa array inicial é:<br>";
print_r($arr);
echo "<br><br>";

$arr[] = 'alicate';
$arr[] = 'marreta';
$arr[] = 'serrote';

echo "agora a nossa array é:<br>";
print_r($arr);
echo"<br>";
//Nomes: Wallace, Joyce, Igor
?>