
package revisao2;

public class Principal {

    public static void main(String[] args) {
        ProfessorMestrado prof;
        prof = new ProfessorMestrado (
                "0t010055",
                "Carlos Mattos",
                500,
                10,
                2023,
                2
        );
        
        // calculando o salario bruto
        prof.calculaSalarioBruto("Graduacao");
        imprime(prof);
        
        // mestrado
        prof.salBruto = 600;
        prof.calculaSalarioBruto("Mestrado");
        imprime(prof);
    }
    
    public static void imprime(ProfessorMestrado prof){
        System.out.println("\nDados\n");
        System.out.println("Nome: " + prof.nome);
        System.out.println("Matricula: " + prof.matricula);
        System.out.println("Sal. Bruto: " + prof.salBruto);
        System.out.println("Qtde Disciplinas: " + prof.qtdeDisc);
        System.out.println("Term. Doutorado: " + prof.AnoTermDoutorado);
        System.out.println("Qtde Artigos: " + prof.qtdeArtigos);
    }
}
