
package com.mycompany.polimorfismoexemplo1;

public class Ferrari implements Carro {

    @Override
    public void acelerar() {
        System.out.println("Ferrari acelerando…");        
    }
    
}


