
package exemploclasse1;

public class Conta {
    // declaração dos atributos da classe
    public String nomeTitular;
    public String nroConta;
    public double limite;
    public double saldo;
    
    // métodos da classe
    public void Depositar(double valor) {
        this.saldo += valor;
    }
    public boolean Sacar(double valor) {
        double nsaldo = this.limite + this.saldo;
        
        if (nsaldo >= valor) {
            this.saldo -= valor;
            return true;
        }
        return false;
    }
}


