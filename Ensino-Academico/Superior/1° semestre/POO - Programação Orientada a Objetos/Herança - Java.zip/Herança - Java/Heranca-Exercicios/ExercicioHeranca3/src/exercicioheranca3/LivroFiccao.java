
package exercicioheranca3;

public class LivroFiccao extends Escritas {
    private String Autor;
    
    public void InserirLivroFicao () {
        super.setNome("Harry Potter");
        super.setTipo("Ficcao");
        this.Autor = "Joanne";
        
    }
    public void MostrarLivroFiccao(){
        System.out.println("Titulo Livro: " + super.getNome());
        System.out.println("Genero Livro: " + super.getTipo());
        System.out.println("Autor do Livro: " + this.Autor);
    }
    
}
