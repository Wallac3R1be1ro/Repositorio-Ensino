﻿
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.FormularioBD
{
    public class ConexaoBancoDados
    {
        // Objeto de conexão com banco
        public MySqlConnection conn = null;

        // Objeto de transação com o banco de dados
        public MySqlTransaction transaction = null;

        // Objeto de comando do banco de dados
        public MySqlCommand cmd = null;

        public MySqlDataReader reader;

        // Construtor da classe
        public ConexaoBancoDados() 
        {
            
        }

        // Metodo de conexao mesmo
        public void ConectarBancoDados()
        {
            try
            {
                // execucao

                // dataSorce da conexao (configuração)
                string data_source = "datasource=127.0.0.1;username='root';password='';" +
                                     "database='metodista'; Allow Zero Datetime=true";

                // criando a conexão 
                conn = new MySqlConnection(data_source);
                cmd = conn.CreateCommand();

                // e abrindo o banco de dados
                conn.Open();
                transaction = conn.BeginTransaction();

                // Deve atribuir o objeto de transação e a conexão ao objeto
                // Command para uma transação local pendente
                cmd.Connection = conn;
                cmd.CommandTimeout = 99999;
                cmd.Transaction = transaction;

            }
            catch (Exception ex)
            {
                // erro
                MessageBox.Show("Erro de conexão com o banco de dados!");
                if (conn != null) { conn.Close(); conn = null; }
                return;
            }

        }

        // metodo de busca de registo no banco de dados
        public MySqlDataReader BuscaDados(string sql)
        {
            try
            {
                // executar o comando insert no banco
                cmd = new MySqlCommand(sql, conn);

                // executar a query
                reader = cmd.ExecuteReader();

                return reader;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro de busca!!!");
                reader = null;
                return reader;
            }
        }
        public void UpdateDados()
        {
            try
            {
                cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                transaction.Commit();
            }
            catch (MySqlException ex) 
            {
                try
                {
                    transaction.Rollback();
                }
                catch (MySqlException ex1)
                {
                    MessageBox.Show(ex1.ToString());
                }
            }
        }

        // metodo de apagar/excluir
        public bool ApagarDados(string sql)
        {
            try
            {
                // executar o comando insert no banco
                cmd = new MySqlCommand(sql, conn);

                // executar a query
                reader = cmd.ExecuteReader();

                return true;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro de busca!!!");
                reader = null;
                return false;
            }
        }

        // metodo de incluir
        public bool IncluirDados(string sql)
        {
            try
            {
                // executar o comando insert no banco
                cmd = new MySqlCommand(sql, conn);

                // executar a query
                reader = cmd.ExecuteReader();

                return true;
            }
            catch (Exception)
            {
                MessageBox.Show("Erro de busca!!!");
                reader = null;
                return false;
            }
        }
    }
}
