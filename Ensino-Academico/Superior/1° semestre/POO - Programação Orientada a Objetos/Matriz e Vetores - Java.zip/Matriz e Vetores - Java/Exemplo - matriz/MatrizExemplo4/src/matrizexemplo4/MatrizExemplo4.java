/*
    Faça um programa que preencha uma matriz 7 x 7 de números inteiros e crie
    dois vetores com sete posições cada um que contenham, respectivamente, o 
    maior elemento de cada uma das linhas e o menor elemento de cada um das 
    colunas. Escreva a matriz e os dois vetores gerados.

 */
package matrizexemplo4;

import java.util.Random;

public class MatrizExemplo4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] mat = new int[7][7];
        int[] vet1 = new int[7];
        int[] vet2 = new int[7];
        int x, y, maior, menor;
        
        // gerador de numeros randomicos
        Random rand = new Random();
        
        // gerando os numeros aleatorios para a matriz
        for (x = 0; x < 7; x++) {
            for (y = 0; y < 7; y++) {
                mat[x][y] = (int)rand.nextInt(50); // gera nros aleatorios
            }
        }
        
        // buscando o maior valor na matriz (linha)
        for (x = 0; x < 7; x++) {
            maior = mat[x][0];
            for (y = 0; y < 7; y++) {
                if (mat[x][y] > maior) {
                    maior = mat[x][y];
                }
            }
            vet1[x] = maior; // guarda o maior valor da linha matriz no vetor1
        }
        
        // buscando o menor valor da matriz (linha)
        for (x = 0; x < 7; x++) {
            menor = mat[x][0];
            for (y = 0; y < 7; y++) {
                if (mat[x][y] > menor) {
                    menor = mat[x][y];
                }
            }
            vet2[x] = menor; // guarda o menor valor da linha matriz no vetor1
        }
        
        // vamos imprimir todos os dados (matriz, vet1, vet2)
        System.out.println("Imprimindo a matriz");
        for (x = 0; x < 7; x++) {
            for (y = 0; y < 7; y++) {
                System.out.print(mat[x][y] + " ");
            }
            System.out.println("");
        }
       
        // vamos imprimir todos os dados vet1
        System.out.println("\nImprimindo o vetor-1");
        for (x = 0; x < 7; x++) {
            System.out.print(vet1[x] + " ");
        }   
        System.out.println("");

        // vamos imprimir todos os dados vet2
        System.out.println("\nImprimindo o vetor-2");
        for (x = 0; x < 7; x++) {
            System.out.print(vet2[x] + " ");
        }   
        System.out.println("");        
    }
    
}
