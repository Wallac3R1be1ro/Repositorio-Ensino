﻿using Metodista.BancoDados;
using Metodista.ConsultarProdutos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.AlterarProdutos
{
    public partial class Frm_AlterarValor : Form
    {
        // declara os atributos
        ConexaoBancoDados db = new ConexaoBancoDados();
        private string codigo, valor;
        private string sql;

        // construtor da classe
        public Frm_AlterarValor(string codigo, string valor)
        {
            InitializeComponent();
            this.codigo = codigo;
            this.valor = valor;
        }

        private void Frm_AlterarValor_Load(object sender, EventArgs e)
        {
            tValor.Text = this.valor;
        }

        private void lblNaoOK_Click(object sender, EventArgs e)
        {
            // fecha o banco se estiver aberto 
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fecha o formulario 
            Frm_AlterarValor.ActiveForm.Close();

        }

        private void lblOK_Click(object sender, EventArgs e)
        {

            try
            {
                // conectando o banco de dados
                db.ConectarBancoDados();
                                                                
                this.valor = tValor.Text.Trim(); // 59,013  1.350,55

                // tratamento do valor digitado caso haja (.) e (,)
                string temp = "";
                for (int i = 0; i < this.valor.Length; i++)
                {
                    if (this.valor[i].Equals('.'))
                    {
                        temp += "";

                    } else if (this.valor[i].Equals(','))
                    {
                        temp += ".";

                    } else
                    {

                        temp += this.valor[i];

                    }
                }
                this.valor = temp;

                // preparando a query (update)
                sql = "update precoproduto set preco = '" + this.valor + "' " +
                      " where codigo = '" + this.codigo + "'; ";

                db.UpdateDados(sql);
                MessageBox.Show("Valor alterado com sucesso!!!");

              
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error: " + ex.Message);
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
            }
            finally
            {
                if (db.conn != null) { db.conn.Close(); db.conn = null; }
            }
        }

        private void Frm_AlterarValor_FormClosed(object sender, FormClosedEventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_AlterarValor.ActiveForm.Close();
        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados caso esteja aberto
            if (db.conn != null) { db.conn.Close(); db.conn = null; }

            // fechando o formulario
            Frm_AlterarValor.ActiveForm.Close();
        }
    }
}
