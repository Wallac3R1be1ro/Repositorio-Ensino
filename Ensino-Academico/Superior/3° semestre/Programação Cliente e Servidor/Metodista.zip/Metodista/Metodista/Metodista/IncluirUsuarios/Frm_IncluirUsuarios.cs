﻿using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.IncluirUsuarios
{
    public partial class Frm_IncluirUsuarios : Form
    {
        private ConexaoBancoDados db = new ConexaoBancoDados();
        private MySqlDataReader reader;
        public String sql;

        public Frm_IncluirUsuarios()
        {
            InitializeComponent();
        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            //Fechando BD
            if (db.conn != null) { db.conn.Close(); }

            //Fechando Form
            Frm_IncluirUsuarios.ActiveForm.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblCancelar_Click(object sender, EventArgs e)
        {
            //Fechando BD
            if (db.conn != null) { db.conn.Close(); }

            //Fechando Form
            Frm_IncluirUsuarios.ActiveForm.Close();
        }

        private void lblConfirmar_Click(object sender, EventArgs e)
        {
            try
            {
                // Conectar BD
                db.ConectarBancoDados();

                // Verificar se foi digitado usuário e senha
                if (String.IsNullOrEmpty(tUsu.Text))
                {
                    MessageBox.Show("Digite seu Usuário");
                    tUsu.Focus();
                    return;
                }
                if (String.IsNullOrEmpty(tSenha.Text))
                {
                    MessageBox.Show("Digite sua Senha");
                    tSenha.Focus();
                    return;
                }

                // Verificar se usuário já existe
                if (reader != null) { reader.Close(); reader = null; }

                //preparando query
                sql = "select usuario from tab_usuarios where usuario = '" + tUsu.Text + "';";

                //buscando o usuario digitado no BD
                reader = db.SelectDados(sql);

                if (reader.HasRows)
                {

                    MessageBox.Show("O usuário ja existe!");


                    if (db.conn != null) { db.conn.Close(); db.conn = null; }

                    tUsu.Focus();
                    return;

                }
                else
                {
                    // Verificar se usuário já existe
                    if (reader != null) { reader.Close(); reader = null; }

                    // preparando a query de inserção
                    sql = "insert into tab_usuarios (Usuario, Senha) values ('" + tUsu.Text + "', '" + tSenha.Text + "');";

                    if (db.InsertDados(sql))
                    {

                        MessageBox.Show("Usuario criado com sucesso!");

                        // limpando o campo para o prox usuario
                        tUsu.Text = "";
                        tSenha.Text = "";
                        // focando usuario para digitação do campo
                        tUsu.Focus();

                        // Comando para aprovar o insert acima
                        db.CommitBanco();
                        //Fechando BD
                        if (db.conn != null) { db.conn.Close(); db.conn = null; }

                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: " + ex.Message);

                //Fechando BD
                if (db.conn != null) { db.conn.Close(); }

                return;

            }
        }
    }
}
