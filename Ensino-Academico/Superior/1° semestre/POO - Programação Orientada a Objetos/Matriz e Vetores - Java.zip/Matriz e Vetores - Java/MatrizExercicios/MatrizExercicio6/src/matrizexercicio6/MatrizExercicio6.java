/*
    Elabore um programa que preencha uma matriz 6 x 4, desenvolva: 

    a) recalcule a matriz digitada onde cada linha deverá ser multiplicada pelo 
       maior elemento da linha em questao; 
    b) mostre a matriz inicial e a matriz resultante.

 */
package matrizexercicio6;

public class MatrizExercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
