<?php
$arr = array();
$arr[] = 'martelo';
$arr[] = 'furadeira';
$arr[] = 'serra';
$arr[] = 'alicate';

print_r($arr)
//Nomes: Wallace, Joyce, Igor
?>