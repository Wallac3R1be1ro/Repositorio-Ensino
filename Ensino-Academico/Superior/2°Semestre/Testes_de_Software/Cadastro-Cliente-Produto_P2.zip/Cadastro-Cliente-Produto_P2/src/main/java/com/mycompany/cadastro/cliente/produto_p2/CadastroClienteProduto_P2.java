package com.mycompany.cadastro.cliente.produto_p2;
import java.io.IOException;
import java.util.Scanner;

public class CadastroClienteProduto_P2 {

    public static void main(String[] args) {
        Scanner ler = new Scanner(System.in);
        // Instanciando variaveis do cliente
        String nome1, tel1, email1, endereco1, cidade1;
        int dia1, mes1, ano1, rg1, cargo1;
        
        // Instanciando variaveis do produto
        int codprod1, quantprod1;
        Float valorprod1;
        String prod1;
        
        //-------------------------------------------------
        //--------------Valor Cliente--------------
        //String nomeCidade[] = {"São Bernardo do Campo - SP", "Santo André - SP", "Diadema - SP"};
        //Preencher valores no Scanner
        System.out.println("================");
        System.out.printf("Informe o nome do primeiro cliente: \n");
        nome1 = ler.nextLine();
        //---------------------------------------------------
        System.out.println("================");
        System.out.printf("Informe o telefone do(a) cliente " + nome1 + ": \n");
        tel1 = ler.nextLine();
        //---------------------------------------------------
        System.out.println("================");
        System.out.printf("Informe o e-mail do(a) cliente " + nome1 + ": \n");
        email1 = ler.nextLine();
        //---------------------------------------------------
        /*System.out.println("================");
        System.out.println("Escolha sua cidade/municipio: ");
        System.out.println("================");
        for (int i=0; i<3; i++) {
        System.out.printf(" %0,2d- %s\n", (i+1), nomeCidade[i]);
        }*/
        //---------------------------------------------------
        System.out.println("================");
        System.out.println("Cidades");
        System.out.println("1 - São Bernardo do Campo");
        System.out.println("2 - Santo André");
        System.out.println("3 - Diadema");
        System.out.printf("Digite o número de sua cidade " + nome1 + ": \n");
        int cidade = ler.nextInt();
        
        System.out.println("================");
        System.out.print("Digite o primeiro dia de nascimento do(a) cliente " + nome1 + ": \n");
        dia1 = ler.nextInt();
        //---------------------------------------------------
        System.out.println("================");
        System.out.print("Digite o mês de nascimento do(a) cliente " + nome1 + ": \n");
        mes1 = ler.nextInt();
        //---------------------------------------------------
        System.out.println("================");
        System.out.print("Digite o ano de nascimento do(a) cliente " + nome1 + ": \n");
        ano1 = ler.nextInt();
        
        System.out.println("================");
        System.out.println("Área Profissional");
        System.out.println("1 - Tecnologia");
        System.out.println("2 - Engenharia");
        System.out.println("3 - Pedagogia");
        System.out.println("4 - Administração");
        System.out.println("5 - Química");
        System.out.println("6 - Mecatronica");
        System.out.println("7 - Exatas");
        System.out.println("8 - Outros");
        System.out.printf("Digite o número de(a) sua profissão " + nome1 + ": \n");
        cargo1 = ler.nextInt();
        
        //-------------------------------------------------
        //--------------Valor produto--------------
        
        /*System.out.println("================");
        System.out.printf("Informe o nome do produto: \n");
        prod1 = ler.nextLine();
        //---------------------------------------------------
        System.out.println("================");
        System.out.printf("Informe o código do primeiro produto: \n");
        codprod1 = ler.nextInt();
        //---------------------------------------------------
        //---------------------------------------------------
        System.out.println("================");
        System.out.printf("Informe a quantidade do produto: \n");
        quantprod1 = ler.nextInt();
        //---------------------------------------------------
        System.out.println("================");
        System.out.printf("Informe o valor do produto: \n");
        valorprod1 = ler.nextFloat();*/
        //---------------------------------------------------
        //---------------------Resultados------------------------
        System.out.println("================");
        System.out.printf("==========Dados do cliente=========");
        System.out.println("\nNome do cliente: " + nome1);
        System.out.println("Telefone do cliente: " + tel1);
        System.out.println("E-mail do cliente: " + email1);
        System.out.println("Data de Nascimento: " + dia1 + "/" + mes1 + "/" + ano1);
        System.out.printf("Cidade: ");
        switch(cidade){
            case 1:
                System.out.println("São Bernardo do Campo");
                break;
            case 2:
                System.out.println("Santo André");
                break;
            case 3:
                System.out.println("Diadema");
                break;
            default:
                System.out.println("Local não identificado!");
                break;
        }
        System.out.printf("Profissão: ");
        switch(cargo1){
            case 1:
                System.out.println("Tecnologia");
                break;
            case 2:
                System.out.println("Engenharia");
                break;
            case 3:
                System.out.println("Pedagogia");
                break;
            case 4:
                System.out.println("Administração");
                break;
            case 5:
                System.out.println("Química");
                break;
            case 6:
                System.out.println("Mecatronica");
                break;
            case 7:
                System.out.println("Exatas");
                break;
            case 8:
                System.out.println("Outros");
                break;
            default:
                System.out.println("Profissão não identificada!");
                break;
                //---------------------------------------------------
        }
        System.out.println("================");
        //System.out.println("=========Dados Produto==========");
        //System.out.println("\nNome do primeiro produto: " + prod1);
       // System.out.println("\nCódigo do primeiro produto: " + codprod1);
        //System.out.println("\nQuantidade do primeiro produto: " + quantprod1);
        //System.out.println("\nValor do primeiro produto: " + valorprod1);
    }
}
