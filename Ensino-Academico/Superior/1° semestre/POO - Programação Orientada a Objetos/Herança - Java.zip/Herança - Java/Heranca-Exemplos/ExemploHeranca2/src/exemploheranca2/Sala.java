
package exemploheranca2;

public class Sala extends Aluno{
    
    
    // metodo da classe Sala
    public String PreparaNotas() {
        String aux="";
        
        aux += String.format("%.1f", super.getN1()) + "    ";
        aux += String.format("%.1f", super.getN2()) + "    ";
        aux += String.format("%.1f", super.getN3()) + "    ";
        aux += String.format("%.1f", super.getN4()) + "\n";
        return aux;
    }
    public String situacaoAluno() {
        
        if (super.getMedia() <= 4) {
            return "Aluno reprovado";
        } else if (super.getMedia() > 4 && super.getMedia() <= 6) {
            return "Aluno em exame";
        } else {
            return "Aluno aprovado";
        }
    }
}
