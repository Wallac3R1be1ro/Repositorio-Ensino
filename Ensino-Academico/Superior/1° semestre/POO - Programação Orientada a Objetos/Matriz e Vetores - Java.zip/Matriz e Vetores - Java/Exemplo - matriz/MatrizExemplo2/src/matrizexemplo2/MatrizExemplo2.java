/*
    Faça um programa que preencha:

    a) um vetor com oito posiçoes, contendo nomes de lojas
    b) outro vetor com quatro posiçoes, contendo nomes de produtos
    c) um matriz com os preços de todos os produtos em cada loja

    O programa deverá mostrar todas as relaçoes (nome do produto - nome da loja)
    em que o preço nao utltrapasse o valor de R$ 120,00.

 */
package matrizexemplo2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MatrizExemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] lojas = new String[8];
        String[] produtos = new String[4];
        double [][] precos = new double[4][8];
        int x, y;
        
        try {
            
            // preenchendo os nomes das lojas
            for (x = 0; x < 8; x++) {
                System.out.print("Digite o nome da loja: ");
                lojas[x] = sc.nextLine();
            }
            
            // preenchendo os produtos
            System.out.println(""); // pula uma linha em branco
            for (x = 0; x < 4; x++) {
                System.out.print("Digite o nome dos produtos: ");
                produtos[x] = sc.nextLine();
            }
            
            // preenchendo os preços dos quatros produtos nas 8 lojas
            System.out.println(""); // pula uma linha em branco
            for (x = 0; x < 4; x++) {
                for (y = 0; y < 8; y++) {
                    System.out.print("Digite o preço do produto " + x);
                    precos[x][y] = sc.nextDouble();
                }
            }
            
            // resolvendo e mostrando a relação pedida no exercicio
            System.out.println(""); // pula uma linha em branco
            for (x = 0; x < 4; x++) {
                for (y = 0; y < 8; y++) {
                    if (precos[x][y] < 120) {
                        System.out.println("Produto: " + produtos[x] + " loja: " + lojas[y] + " preço R$ " + precos[x][y]);
                    }
                }
            }
            
        } catch (InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
