/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemploheranca1;

/**
 *
 * @author clsma
 */
public class Fornecedor extends Pessoa {
    // declarando os atributos da classe Fornecedor
    private double valorCredito;
    private double valorDivida;
    
    
    // metodo da classe Fornecedor
    public double obterSaldo() {
       // devolve a diferença entre os valores dos 
       // atributos valorCredito e valorDivida
       
       return (this.valorCredito - this.valorDivida);
    }
    
    // metodos get's e set's
    public double getValorCredito() {
        return valorCredito;
    }
    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }
    public double getValorDivida() {
        return valorDivida;
    }
    public void setValorDivida(double valorDivida) {
        this.valorDivida = valorDivida;
    }
    
}
