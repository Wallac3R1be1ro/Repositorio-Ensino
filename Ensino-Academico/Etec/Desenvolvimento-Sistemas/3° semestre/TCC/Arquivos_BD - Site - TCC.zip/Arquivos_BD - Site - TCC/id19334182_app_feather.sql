-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 27-Nov-2022 às 18:03
-- Versão do servidor: 10.5.16-MariaDB
-- versão do PHP: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `id19334182_app_feather`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `produto`
--

CREATE TABLE `produto` (
  `cod` int(11) NOT NULL,
  `nome` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `quant` int(11) NOT NULL,
  `foto` varchar(150) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `produto`
--

INSERT INTO `produto` (`cod`, `nome`, `preco`, `quant`, `foto`) VALUES
(1, 'NA', 0.00, 89, 'https://static.paodeacucar.com/img/uploads/1/869/12557869.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tab`
--

CREATE TABLE `tab` (
  `login` varchar(20) CHARACTER SET latin1 NOT NULL,
  `senha` varchar(20) CHARACTER SET latin1 NOT NULL,
  `foto` varchar(30) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `tab`
--

INSERT INTO `tab` (`login`, `senha`, `foto`) VALUES
('', '', ''),
('joyce', '12347', 'pernalonga.jpg'),
('A', 'A', 'imagem.jpg'),
('Lucas.B', '1234', 'imagem.jpg'),
('a', 'a', 'imagem.jpg'),
('gisele', 'duvido', 'imagem.jpg');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_usuario`
--

CREATE TABLE `tb_usuario` (
  `id_user` int(11) NOT NULL,
  `nome_user` varchar(60) NOT NULL,
  `email_user` varchar(60) NOT NULL,
  `senha_user` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `tb_usuario`
--

INSERT INTO `tb_usuario` (`id_user`, `nome_user`, `email_user`, `senha_user`) VALUES
(1, 'jooj', 'barbosajose931@gmail.com', 'America123'),
(2, 'Joyce ', 'joycemaria991@gmail.com', 'mario1214'),
(3, 'João Pedro Fi do Homem Abobora', 'jojopepedro@hotmail.com', 'souangolano');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `nomeUsuario` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `emailUsuario` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `senhaUsuario` varchar(16) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`nomeUsuario`, `emailUsuario`, `senhaUsuario`) VALUES
('Luan', 'luannbm@gmail.com', '1234faca'),
('Wallace', 'wallacesantos12wr@gmail.com', 'walkl1234'),
('Teste', 'teste@bol.com', 'deletadoserei'),
('antedegmom', 'jojopepedro@hotmail.com', 'macaco'),
('WallaceADMSupremo', 'email', 'email'),
('a', 'a', 'a'),
('', '', ''),
('', '', ''),
('', '', ''),
('wallace', 'wallace@gmail.com', 'a'),
('', '', ''),
('', '', ''),
('', '', ''),
('', '', ''),
('ALINE HOMO SAPIENS', 'NAOSEIISCREVER@GMAIL.COM', 'FODASE');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `produto`
--
ALTER TABLE `produto`
  ADD PRIMARY KEY (`cod`);

--
-- Índices para tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_usuario`
--
ALTER TABLE `tb_usuario`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
