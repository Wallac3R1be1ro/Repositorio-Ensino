/*
    Faça um programa que receba:

    - as notas de 15 alunos em cinco provas diferentes e armazene-as em uma 
      matriz 15 x 5;
    - os nomes dos 15 alunos e armazene-os em um vetor de 15 posiçoes.

    O programa deverá calcular e mostrar:

    a) para cada aluno, o nome, a media aritmetica das cinco provas e a situação
       (6 ou acima - aprovado,0 a 3 - reprovado ou 4 a 6 - exame);
    b) a media da classe.

 */
package matrizexercicio4;

//import java.util.InputMismatchException;
import java.util.Scanner;

public class MatrizExercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Scanner sc = new Scanner(System.in);
        String[] nomes;
        nomes = new String[5];
        
        double [] notas = new double[5];
        double soma = 0, media;
        
            for (int i = 0; i < 5; i++) {
                System.out.println("Digite o nome do aluno: ");
                nomes[i] = new Scanner(System.in).nextLine();
                
                System.out.println("Digite a nota da prova do aluno(a): "+nomes[i]);
                notas[i] = new Scanner(System.in).nextDouble();
                soma = soma + notas[i];
            }
            
            media = soma / 5;
            System.out.println("A media dos Alunos é: " + media);
            System.out.println();
            //System.out.println("Aqui estão os Alunos com média superior a turma");
            for(int i=0; i<=5; i++){
                //System.out.println(nomes[i]);
            if(notas[i] >= 3){
                System.out.println(nomes[i] + " foi reprovado(a)!");
            }
            System.out.println("----------------------------");
            if(notas[i] >= 5){
                System.out.println(nomes[i] + " está em exame!");
            }
            System.out.println("----------------------------");
            if (notas[i] >= 6){
                System.out.println(nomes[i] + " foi aprovado(a)!");
            }
            System.out.println("----------------------------");
            //--------------------------------------------------------
            }
            
        }
}
        
