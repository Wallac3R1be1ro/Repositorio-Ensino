
package com.mycompany.contatenar;

import javax.swing.JOptionPane;

public class Contatenar {
    //Concatenar

    public static void main(String[] args) {
        String aux = "";
        String Nome;
        String Cel;
        String Email;
        
        Nome = JOptionPane.showInputDialog("Digite seu nome:");
        Cel = JOptionPane.showInputDialog("Digite seu Cel:");
        Email = JOptionPane.showInputDialog("Digite seu E-mail:");
        
        aux = "\nImprimindo os dados\n";
        aux += "Nome: " + Nome + "\n";
        aux += "Celular: " + Cel + "\n";
        aux += "E-Mail: " + Email + "\n";
        JOptionPane.showMessageDialog(null, aux);
        
        
        /*aux = "\nExemplo de concatenação\n";
        aux += "Primeiro texto\n";
        aux += "Segundo texto\n";
        aux += "Terceiro texto\n";
        aux += 123 + "\n";
        JOptionPane.showMessageDialog(null, aux);*/
    }
}
