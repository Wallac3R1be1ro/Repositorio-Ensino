/*
    Faça um programa que preencha uma matriz 3 x 5 com números inteiros, calcule
    e mostre a quantidade de elementos entre 15 e 20.

    
 */
package matrizexercicio1;

public class MatrizExercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
