/*
    Faça um projeto criando a classe responsavel que leia um vetor A de dez
    posiçoes contendo números inteiros. Determine e mostre, a seguir, quais
    elementos de A estão repetidos e quantas vezes cada um se repete.

    Exemplo: vetor A
    5   4   3   18  5   3   4   18  4   18

    Caso sejam digitados valores como os apresentados no vetor A, o programa
    deverá mostrar ao final as seguintes informações:

    - o número 5 aparece duas vezes
    - o número 5 aparece tres vezes
    - o número 3 aparece duas vezes
    - o número 18 aparece tres vezes

 */
package classeexercicio3;

public class ClasseExercicio3 {

    public static void main(String[] args) {
        
    }
    
}
