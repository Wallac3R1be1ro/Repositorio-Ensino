/*
    Crie um programa que leia um vetor V contendo 18 elementos. A seguir, o 
    programa deverá distribuir esses elementos em uma matriz 3 x 6 e, no final,
    mostrar a matriz gerada.
    
 */
package matrizexemplo5;

import java.util.Random;

public class MatrizExemplo5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        int[] vetV = new int[18];
        int[][] mat = new int[3][6];
        int x, nlin, ncol;
        
        // gerando os nros aleatorios para o vetor
        for (x = 0; x < 18; x++) {
            vetV[x] = (int) rand.nextInt(100);
        }
        
        // colocando os valores do vetor na matriz
        nlin = 0;
        ncol = 0;
        for (x = 0; x < 18; x++) {
            
            mat[nlin][ncol] = vetV[x];
            ncol += 1;
            
            if (ncol > 5){
                ncol = 0;
                nlin += 1;
            }
        }
        
        // vamos imprimir os valores da matriz e também do vetor
        System.out.println("Valores da matriz");
        for (nlin = 0; nlin < 3; nlin++) {
            for (ncol = 0; ncol < 6; ncol++) {
                System.out.print(mat[nlin][ncol] + " ");
            }
            System.out.println("");
        }
        
        System.out.println("\nValores do vetor");
        for (x = 0; x < 18; x++) {
            System.out.print(vetV[x] + " ");
        }
        System.out.println("");
    }
    
}
