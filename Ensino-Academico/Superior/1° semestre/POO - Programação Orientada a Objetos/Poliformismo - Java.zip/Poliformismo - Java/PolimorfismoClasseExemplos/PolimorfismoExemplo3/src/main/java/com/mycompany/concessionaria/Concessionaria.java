
package com.mycompany.concessionaria;

public class Concessionaria {

    public static void main(String[] args) {
        Carro objeto;
        
        objeto = new Fusca();
        objeto.AumentoAnual();
        objeto.ApresentaCarro();
        
        objeto = new Golf();
        objeto.AumentoAnual();
        objeto.ApresentaCarro();
        
        objeto = new Renault();
        objeto.AumentoAnual();
        objeto.ApresentaCarro();
        
    }
}
