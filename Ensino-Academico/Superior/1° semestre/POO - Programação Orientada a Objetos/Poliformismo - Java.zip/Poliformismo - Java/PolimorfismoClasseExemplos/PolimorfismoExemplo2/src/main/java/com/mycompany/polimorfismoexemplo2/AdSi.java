
package com.mycompany.polimorfismoexemplo2;

public class AdSi implements Conexao {

    @Override
    public void conectar() {
        System.out.println("Adsl conectado…");
    }
    
}


