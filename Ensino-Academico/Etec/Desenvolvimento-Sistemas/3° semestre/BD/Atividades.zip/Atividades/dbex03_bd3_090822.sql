-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Tempo de geração: 16-Ago-2022 às 17:27
-- Versão do servidor: 8.0.21
-- versão do PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dbex03_bd3_090822`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_cliente`
--

DROP TABLE IF EXISTS `tb_cliente`;
CREATE TABLE IF NOT EXISTS `tb_cliente` (
  `COD_CLIENTE` int NOT NULL,
  `NOME_CLIENTE` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `DTA_NASC_CLIENTE` date NOT NULL,
  `DTA_CAD_CLIENTE` datetime NOT NULL,
  `SALDO_CLIENTE` decimal(6,2) NOT NULL,
  PRIMARY KEY (`COD_CLIENTE`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `tb_cliente`
--

INSERT INTO `tb_cliente` (`COD_CLIENTE`, `NOME_CLIENTE`, `DTA_NASC_CLIENTE`, `DTA_CAD_CLIENTE`, `SALDO_CLIENTE`) VALUES
(20121, 'Fabio', '1978-09-05', '1995-04-03 00:00:00', '15.13'),
(30301, 'Ana Paula', '1978-09-22', '1995-03-10 00:00:00', '32.67'),
(37501, 'João Pedro', '1983-11-14', '2005-03-20 00:00:00', '14.52'),
(39922, 'Joana', '1992-05-12', '2012-05-04 00:00:00', '0.78'),
(40378, 'Paulo', '1998-09-23', '2022-08-16 13:57:22', '20.00');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
