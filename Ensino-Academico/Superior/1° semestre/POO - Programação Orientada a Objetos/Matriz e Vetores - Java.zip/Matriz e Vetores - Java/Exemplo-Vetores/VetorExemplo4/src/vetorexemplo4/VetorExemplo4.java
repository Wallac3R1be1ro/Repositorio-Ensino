/*
    Faça um programa que preencha um primeiro vetor com dez números inteiros 
    e um segundo vetor com cinco números também inteiros e positivos. O programa
    deverá mostrar uma lista dos números do primeiro vetor com seus respectivos
    divisores armazenados no segundo vetor, bem como suas posiçoes.

    

 */
package vetorexemplo4;

public class VetorExemplo4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int [] nros = new int[10];
        int [] divisores = new int[5];
        int x, y;
        
        // atribuindo os valores no vetor
        nros[0] = 5;
        nros[1] = 12;
        nros[2] = 4;
        nros[3] = 7;
        nros[4] = 10;
        nros[5] = 3;
        nros[6] = 2;
        nros[7] = 6;
        nros[8] = 23;
        nros[9] = 16;
        
        // atribuindo os valores dos divisores
        divisores[0] = 3;
        divisores[1] = 11;
        divisores[2] = 5;
        divisores[3] = 8;
        divisores[4] = 2;
        
        // verificando se primeiro vetor é divisivel pelo segundo vetor
        for (x = 0; x < 10; x++) {           
            
            // imprimindo o primeiro numero do vetor nros
            System.out.println("Número: " + nros[x]);
            
            for (y = 0; y < 5; y++) {                
                
                // verifica se é divisivel 
                if (nros[x] % divisores[y] == 0) {
                    // imprimindo o divisor e sua posição
                    System.out.println("Divisivel por " + divisores[y] +" e na posição " + y);
                }
                
            }
        }
        
    }
    
}
