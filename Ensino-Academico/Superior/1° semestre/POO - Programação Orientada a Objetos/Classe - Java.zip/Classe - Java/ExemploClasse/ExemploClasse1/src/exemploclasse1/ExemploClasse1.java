/*
    Criar uma classe Conta e fazer algumas transações de saque e deposito, 
    lembrando que, para o saque a classe Conta deve verificar se existe saldo
    suficiente para tal transação.

 */
package exemploclasse1;

public class ExemploClasse1 {

    public static void main(String[] args) {
        // declarando a classe Conta
        Conta conta = new Conta();
        
        // atribuindo valores aos atributos da classe Conta
        conta.nomeTitular = "Antonio Carlos Silva";
        conta.nroConta = "51.237-8";
        conta.limite = 100.0;
        conta.saldo = 150;
        
        // fazendo a transação de saque
        if ( conta.Sacar(560) ) {
            System.out.println("Transação efetuada com sucesso!");
        } else {
            System.out.println("Saldo insuficiente!");
        }
        
        // fazendo a transação de depositar
        conta.Depositar(890);
        
    }
    
}


