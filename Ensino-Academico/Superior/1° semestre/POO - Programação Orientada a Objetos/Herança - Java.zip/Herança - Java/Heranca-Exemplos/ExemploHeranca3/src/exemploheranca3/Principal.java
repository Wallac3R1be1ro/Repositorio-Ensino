/*
    Monte o codigo em Java de acordo com se pede:

    a) As classes Diretor e Gerente derivam da classe FuncionarioAutenticavel
    b) As classes Secretario, Engenheiro derivam da classe Funcionario
    c) Imprima os dados pessoais do gerente.

 */
package exemploheranca3;

import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Gerente gerente = new Gerente("Carlos Eduardo", "(11) 9 9709-8756", "gerente.gerente@faculdade.com.br");
       
        JOptionPane.showMessageDialog(null, gerente.ImprimeDados());
    }
    
}
