/*
    Crie um projeto em Java que:
    a) receba o preço de dez produtos e armazene-os em um vetor.
    b) receba a quantidade estocada de cada um desses produtos em cinco armazens
       diferentes, utilizando um matriz 5 x 10.

    O projeto deverá calcular e mostrar:
    1 - a quantidade de produtos estocados em cada um dos armazens.
    2 - a quantidade de cada um dos produtos estocados em todos os armazens juntos.
    3 - o preço do produto que possui maior estoque em um unico armazem.
    4 - O menor estoque armazenado.
    5 - o custo de cada armazem.

    Desenvolva um classe que atenda todas as necessidades do projeto.

 */
package exemploclasse6;

public class ExemploClasse6 {

    public static void main(String[] args) {
        Estoque estoque = new Estoque();

         // gerando os preços dos 10 produtos aleatoriamente
         estoque.geraPreco();
        
        // gerando as quantidades em cada armazem para cada produto
        estoque.geraQtdeArmazem();
        
        // item 1
        estoque.qtdeProdutosEstocados();
        
        // item 2
        estoque.qtdeProdutosArmazens();
        
        // item 3
        estoque.precoMaiorEstoque();
        
        // item 4
        estoque.menorEstoqueArmazenado();
        
        // item 5
        estoque.custoCadaArmazem();
        
    }
    
}
