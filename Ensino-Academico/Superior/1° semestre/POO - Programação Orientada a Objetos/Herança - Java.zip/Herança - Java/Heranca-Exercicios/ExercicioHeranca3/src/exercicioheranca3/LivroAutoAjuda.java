package exercicioheranca3;

public class LivroAutoAjuda extends Escritas{
    private String Autor;
    
    public void InserirLivroAutoAjuda(){
        super.setNome("Fundo do Poço");
        super.setTipo("Auto Ajuda");
        this.Autor = "Vanessa";
    }
    public void MostrarLivroAutoAjuda(){
        System.out.println("Titulo Livro: " + super.getNome());
        System.out.println("Gênero Livro: " + super.getTipo());
        System.out.println("Autor Livro: " + this.Autor);
        
    }
    
}
