/*
Criar uma classe Conta, que possua um saldo e os métodos para pegar saldo, 
depositar e sacar. Adicione um método na classe Conta que atualiza essa conta 
de acordo com uma taxa percentualfornecida.
 
Crie duas subclasses da classe Conta: ContaCorrente e ContaPoupanca. Ambas 
terão o métodoatualiza reescrito: A ContaCorrente deve ser atualizada com o 
dobro da taxa e a ContaPoupanca com o triploda taxa. Além disso, a ContaCorrente 
deve reescrever o método deposita, com o objetivo de retirar uma taxabancária de 
dez centavos de cada depósito.

Crie uma classe TestaContas com o método main e instancie estas classes, 
atualize-as e veja oresultado imprimindo o saldo.

 */

package com.mycompany.polimorfismoexercicio1;

public class PolimorfismoExercicio1 {

    public static void main(String[] args) {
        
    }
}
