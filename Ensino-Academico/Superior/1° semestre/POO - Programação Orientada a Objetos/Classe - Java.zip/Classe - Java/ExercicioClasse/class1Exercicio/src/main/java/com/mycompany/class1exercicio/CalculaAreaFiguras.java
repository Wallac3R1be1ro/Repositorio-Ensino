package com.mycompany.class1exercicio;

public class CalculaAreaFiguras {
    // Declarando os atributos da classe
    public double base;
    public double altura;
    public double raio;
    public double lado;
    
    // Declarando os metodos da classe
    public double calculaArea(String figura){
        double res = 0;
        
        if(figura.toUpperCase().equals("TRIANGULO")){
            res = (this.base * this.altura) / 2;
        }else if(figura.toUpperCase().equals("QUADRADO")){
            res = this.lado * this.lado;
        }else if(figura.toUpperCase().equals("CIRCULO")){
            res = 3.1415 * (this.raio * this.raio);
        }
        return res;
    }
    
}
