import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) 
	{
		//Usuario objUs = new Usuario(10, "Mago", "SBC", "Mago123@gmail.com", "E.M�dio");
		
		//Intanciando a classe (Entidade)
		Usuario objUs =
				new Usuario(10, "Player", "SBC",
						"p412@gmail.com", "E.M�dio");
		
		
		//Outra forma de armazenar dados com objUs
		
		//objUs.setId(66);
		//objUs.setName("Wallace");
		//objUs.setEndereco("SBC");
		//objUs.setEmail("Wall12@gmail.com");
		//objUs.setEscolaridade("Graduado");
		
		//Recuperando os Valores
		JOptionPane.showMessageDialog(null,
				"Cadastro de Pessoas Bonitas" +
						"\n Nome: " + objUs.getName()+
						"\n End: " + objUs.getEndereco()+
						"\n End: " + objUs.getEmail()+
						"\n Escol.: " + objUs.getEscolaridade());
		}

}
