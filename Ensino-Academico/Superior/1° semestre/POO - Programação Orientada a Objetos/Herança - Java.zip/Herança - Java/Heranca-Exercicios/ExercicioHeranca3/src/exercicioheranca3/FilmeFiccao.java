/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicioheranca3;

public class FilmeFiccao extends Filmes{
    private String Diretor;
    private String Nome;
    
    public void InserirDadosFilmeFiccao(){
        this.Nome = "Alien";
        this.Diretor = "Steven";
        super.setGênero("Ficção Cientifica");
    }
    public void MostrarFilmeFicção(){
        System.out.println("Nome do filme: " + this.Nome);
                System.out.println("Gênero do filme: " + super.getGênero());
        System.out.println("Diretor do filme: " + this.Diretor);
    }
}
