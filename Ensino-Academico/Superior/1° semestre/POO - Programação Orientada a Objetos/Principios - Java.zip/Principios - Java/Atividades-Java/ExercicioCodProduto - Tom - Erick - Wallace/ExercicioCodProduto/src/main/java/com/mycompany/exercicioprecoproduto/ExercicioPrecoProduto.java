/*
 * Faça um programa que receba o preço de um produto e seu codigo de origem
   e mostre sua procedenci. A procedencia obedece à tabela a seguir:

    CODIGO DE ORIGEM                        PROCEDENCIA
        1                                       SUL
        2                                       NORTE
        3                                       LESTE
        4                                       OESTE
        5 e 6                                   NORDESTE
        7 ou 8 ou 9                             SUDESTE
        10 a 20                                 CENTRO-OESTE
        21 a 30                                 NORDESTE

 */package com.mycompany.exercicioprecoproduto;
/**
 * @authores: wellington alves, Wallace Ribeiro, erick araujo.
 */
public class ExercicioPrecoProduto {

    public static void main(String[] args) {
        //double PrecoProdouto1 = 22;
        //---------------------------------------------------------------------
        //----------------------------Produtos-----------------------------------------
        String nomeProduto1 = "Pão";
        String nomeProduto2 = "salsicha";
        String nomeProduto3 = "manteiga";
        String nomeProduto4 = "fermento";
        String nomeProduto5 = "queijo";
        String nomeProduto6 = "cafe"; 
        String nomeProduto7 = "chocolate";
        String nomeProduto8 = "bombom";
        //---------------------------------------------------------------------
        //-------------------------------Codigo Produto--------------------------------------
        double CodProduto1 = 1;
        double CodProduto2 = 2;
        double CodProduto3 = 3;
        double CodProduto4 = 4;
        double CodProduto5 = 5;
        double CodProduto6 = 8;
        double CodProduto7 = 10;
        double CodProduto8 = 30;

        //----------------------------------Local Produto-----------------------------------
        String procedenciaProduto1 = "Sul";
        String procedenciaProduto2 = "norte";
        String procedenciaProduto3 = "leste";
        String procedenciaProduto4 = "oeste";
        String procedenciaProduto5 = "nordeste";
        String procedenciaProduto6 = "sudeste";
        String procedenciaProduto7 = "centro-oeste";
        String procedenciaProduto8 = "nordeste";
        //---------------------------------------------------------------------
        //------------------------------Operações---------------------------------------
        if(CodProduto1 >= 1 ){
            System.out.println(nomeProduto1 + ", pertence ao " + procedenciaProduto1);
        }
        else if(CodProduto1 <= 1){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto2 >= 2 ){
            System.out.println(nomeProduto2 + ", pertence ao " + procedenciaProduto2);
        }
        else if(CodProduto2 <= 2){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto3 >= 3 ){
            System.out.println(nomeProduto3 + ", pertence ao " + procedenciaProduto3);
        }
        else if(CodProduto3 <= 3){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto4 >= 4 ){
            System.out.println(nomeProduto4 + ", pertence ao " + procedenciaProduto4);
        }
        else if(CodProduto4 <= 4){
            System.out.println("Codigo de produto inválido!");
        }//---------------------------------------------------------------------
        if(CodProduto5 >= 5 ){
            System.out.println(nomeProduto5 + ", pertence ao " + procedenciaProduto5);
        }
        else if(CodProduto5 <= 5){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto6 >= 8 ){
            System.out.println(nomeProduto6 + ", pertence ao " + procedenciaProduto6);
        }
        else if(CodProduto6 <= 8){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto7 >= 10 ){
            System.out.println(nomeProduto7 + ", pertence ao " + procedenciaProduto7);
        }
        else if(CodProduto7 <= 30){
            System.out.println("Codigo de produto inválido!");
        }
        //---------------------------------------------------------------------
        if(CodProduto8 >= 30 ){
            System.out.println(nomeProduto2 + ", pertence ao " + procedenciaProduto8);
        }
        else if(CodProduto8 <= 30){
            System.out.println("Codigo de produto inválido!");
        }
    }
}
