/*
    Faça um programa que preencha dois vetores de dez posiçoes cada um, 
    determine e mostre um terceiro contendo os elementos dos dois vetores
    anteriores ordenados de maneira crescente.

 */
package vetorexercicio2;

public class VetorExercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
