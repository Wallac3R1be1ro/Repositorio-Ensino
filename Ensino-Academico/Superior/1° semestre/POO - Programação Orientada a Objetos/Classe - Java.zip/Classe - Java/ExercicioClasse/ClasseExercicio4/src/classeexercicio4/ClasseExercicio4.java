/*
    Crie um classe que preencha um vetor com quinze elementos inteiros e verifique
    a existencia de elementos iguais a 30, mostrando as posições em que apareceram.

 */
package classeexercicio4;

public class ClasseExercicio4 {

    public static void main(String[] args) {
        
    }
    
}
