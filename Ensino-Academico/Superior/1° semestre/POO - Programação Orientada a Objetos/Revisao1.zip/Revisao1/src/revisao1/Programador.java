
package revisao1;

public class Programador extends Funcionario{
    //Atributos
    public boolean graduacao;
    public double salBase;
    public boolean certificadoJava;
    public String nome;
    public char sexo;
    public int anoNasc;
    
    //Construtor da classe
    // Aplicando a sobrecarga
    
    public Programador(){
        
    }

    public Programador(boolean graduacao, double salBase, boolean certificadoJava, String nome, char sexo, int anoNasc) {
        this.graduacao = graduacao;
        super.salBase = salBase;
        this.certificadoJava = certificadoJava;
        super.nome = nome;
        this.sexo = sexo;
        super.anoNasc = anoNasc;
    }
    
    
    //Metodos da classe
    @Override
    public void Exibe(){
        System.out.println("Dados do profissional Programador" + "\n");
        System.out.println("Nome: " + super.nome);
        System.out.println("Sexo: " + this.sexo);
        System.out.println("Ano Nasc: " + super.anoNasc);
        System.out.println("Salario base: " + super.salBase);
        
        if (this.graduacao){
            System.out.println("Tem graduação: " + "Sim");
        }else {
            System.out.println("Tem graduação: " + "Não");
        }
        
        if (this.certificadoJava){
            System.out.println("Tem certificado Java: " + "Sim");
        }else {
            System.out.println("Tem certificado Java: " + "Não");
        }
  
    }
    public String Exibe (boolean flag){
        String aux = "Dados do Programador";
        
            aux += "Nome: " + super.nome            + "\n;";
            aux += "Sexo: " + this.sexo             + "\n;";
            aux += "Ano nasc: " + super.anoNasc     + "\n;";
            aux += "Salario Base: " + super.salBase + "\n;";
            if (this.graduacao){
                aux += "Tem graduacao: Sim" + "\n;";
            }
            if (this.certificadoJava){
                aux += "Tem certificado Java: Sim" + "\n;";
            }else {
                aux += "Ter certificado Java: Não" + "\n;";
            }
            aux += "Final";
        
        return aux;
    }
    
}
