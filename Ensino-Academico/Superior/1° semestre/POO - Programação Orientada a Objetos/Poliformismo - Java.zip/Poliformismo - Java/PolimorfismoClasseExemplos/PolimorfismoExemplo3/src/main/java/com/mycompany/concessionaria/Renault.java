
package com.mycompany.concessionaria;

public class Renault implements Carro {
    public double valorCarro;
   
        
    public Renault() {
        this.valorCarro = 100000;
    }
    
    @Override
    public double AumentoAnual() {
        this.valorCarro *= 1.07;
        return this.valorCarro;
    }

    @Override
    public void ApresentaCarro() {
        System.out.println("Valor do Renault: R$ " + String.format("%.2f", this.valorCarro));
    }
    
}
