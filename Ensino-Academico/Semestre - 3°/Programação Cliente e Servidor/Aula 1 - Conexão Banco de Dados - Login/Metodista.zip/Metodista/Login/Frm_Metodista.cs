﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.Login
{
    public partial class Frm_Metodista : Form
    {
        public Frm_Metodista()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bSair_Click(object sender, EventArgs e)
        {
            //Fechando o sistema
            Application.Exit();
        }

        private void bEntrar_Click(object sender, EventArgs e)
        {
            //Verificando se o usuario digitou algo em tUsuario
            if(String.IsNullOrEmpty( tUsuario.Text ))
            {
                MessageBox.Show("Digite o Usuario!");
                    tUsuario.Focus();
                    return;
            }

            //Vericando se o usuário digitou algo em tSenha
            if (String.IsNullOrEmpty( tSenha.Text ))
            {
                MessageBox.Show("Digite a Senha!");
                    tSenha.Focus();
                    return;
            }
        }
    }
}
