
package exemploheranca2;

public class Aluno {
    // declarando os atributos da classe Aluno
    private String nome;
    private double n1;
    private double n2;
    private double n3;
    private double n4;
    private double media;
    
    // construtor da classe Aluno
    public Aluno() {
        this.nome = "";
        this.n1 = 0;
        this.n2 = 0;
        this.n3 = 0;
        this.n4 = 0;
        this.media = 0; 
    }
    
    // metodo da classe
    public void CalculaMedia() {
        this.media = (this.n1 + this.n2 + this.n3 + this.n4) / 4;
    }
    
    // metodos get's e set's
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public double getN1() {
        return n1;
    }
    public void setN1(double n1) {
        this.n1 = n1;
    }
    public double getN2() {
        return n2;
    }
    public void setN2(double n2) {
        this.n2 = n2;
    }
    public double getN3() {
        return n3;
    }
    public void setN3(double n3) {
        this.n3 = n3;
    }
    public double getN4() {
        return n4;
    }
    public void setN4(double n4) {
        this.n4 = n4;
    }
    public double getMedia() {
        return media;
    }
    public void setMedia(double media) {
        this.media = media;
    }
    
}
