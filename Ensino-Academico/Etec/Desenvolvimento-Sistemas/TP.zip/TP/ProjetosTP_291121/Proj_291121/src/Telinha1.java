import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Telinha1 {

	private JFrame frame;
	private JTextField txtNome;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Telinha1 window = new Telinha1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Telinha1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 190, 207);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnBotao = new JButton("Bot\u00E3o");
		btnBotao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// METODO DO BOTAO!!!
				// Recuperando o valor da caixinha de texto
				String nominho = txtNome.getText();
				
				// MOSTRAR NO JOPTION
				JOptionPane.showMessageDialog(null,
						"Ol�, " + nominho);
			}
		});
		btnBotao.setBounds(37, 56, 89, 23);
		frame.getContentPane().add(btnBotao);
		
		txtNome = new JTextField();
		txtNome.setBounds(40, 25, 86, 20);
		frame.getContentPane().add(txtNome);
		txtNome.setColumns(10);
	}
}
