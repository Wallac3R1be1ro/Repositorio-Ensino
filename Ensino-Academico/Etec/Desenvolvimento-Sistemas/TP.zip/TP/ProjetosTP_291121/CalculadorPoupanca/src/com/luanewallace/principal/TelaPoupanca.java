package com.luanewallace.principal;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class TelaPoupanca {

	private JFrame frame;
	private JTextField txtNome;
	private JTextField txtJuros;
	private JTextField txtAnos;
	private JTextField txtDeposito;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPoupanca window = new TelaPoupanca();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TelaPoupanca() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 392, 245);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbl = new JLabel("Nome: ");
		lbl.setBounds(31, 42, 46, 14);
		frame.getContentPane().add(lbl);
		
		txtNome = new JTextField();
		txtNome.setBounds(204, 40, 140, 17);
		frame.getContentPane().add(txtNome);
		txtNome.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Juros ao m\u00EAs %: ");
		lblNewLabel.setBounds(31, 68, 111, 14);
		frame.getContentPane().add(lblNewLabel);
		
		txtJuros = new JTextField();
		txtJuros.setBounds(204, 66, 140, 17);
		frame.getContentPane().add(txtJuros);
		txtJuros.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Num. de anos: ");
		lblNewLabel_1.setBounds(31, 97, 111, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		txtAnos = new JTextField();
		txtAnos.setBounds(204, 94, 140, 20);
		frame.getContentPane().add(txtAnos);
		txtAnos.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Dep\u00F3sito mensal em R$: ");
		lblNewLabel_2.setBounds(31, 128, 163, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		txtDeposito = new JTextField();
		txtDeposito.setBounds(204, 125, 140, 20);
		frame.getContentPane().add(txtDeposito);
		txtDeposito.setColumns(10);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int anos = Integer.parseInt(txtAnos.getText());
				double dep = Double.parseDouble(txtDeposito.getText());
				double jur = Double.parseDouble(txtJuros.getText());
				int meses = anos * 12;
				double total = 0;
				for(int i = 0; i < meses; i++)
				{
					total += dep;
					total = total + total * (jur/100);
				}
				
				JOptionPane.showMessageDialog(null, "O total poupado � de R$" + total);
			}
		});
		btnCalcular.setBounds(132, 153, 89, 23);
		frame.getContentPane().add(btnCalcular);
	}
}
