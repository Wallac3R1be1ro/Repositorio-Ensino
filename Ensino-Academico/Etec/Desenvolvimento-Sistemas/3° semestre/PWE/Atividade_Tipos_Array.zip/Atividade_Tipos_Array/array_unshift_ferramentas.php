<?php
$ferramentas=array('martelo','furadeira','serra');
array_unshift($ferramentas, 'alicate');
print_r($ferramentas);
//Nomes: Wallace, Joyce, Igor
?>