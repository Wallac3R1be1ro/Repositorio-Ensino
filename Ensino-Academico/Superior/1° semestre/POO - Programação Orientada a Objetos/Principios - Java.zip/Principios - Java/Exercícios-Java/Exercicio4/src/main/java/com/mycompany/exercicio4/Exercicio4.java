package com.mycompany.exercicio4;

public class Exercicio4 {

    public static void main(String[] args) {
        double salBase, gratificacao, imposto, salReceber;
        
        //Atribuindo salBase
        salBase = 1000;
        
        //Aplicando a grafificacao no salario base
        gratificacao = salBase * 0.05;
        
        //Aplicando o imposto
        imposto = (salBase + gratificacao) * 0.07;
        
        //Calculando o salario a receber
        salReceber = (salBase + gratificacao) - imposto;
        
        System.out.println("Salario a receber: " + salReceber);
    }
}
