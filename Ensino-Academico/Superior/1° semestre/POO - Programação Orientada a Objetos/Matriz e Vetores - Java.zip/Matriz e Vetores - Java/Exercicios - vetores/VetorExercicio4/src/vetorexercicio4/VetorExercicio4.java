/*
    Faça um programa que leia dois vetores de dez posiçoes e faça a multiplicacao
    dos elementos de mesmo indice, colocando o resultado em um terceiro vetor.
    Mostre o vetor resultante.

 */
package vetorexercicio4;

public class VetorExercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
