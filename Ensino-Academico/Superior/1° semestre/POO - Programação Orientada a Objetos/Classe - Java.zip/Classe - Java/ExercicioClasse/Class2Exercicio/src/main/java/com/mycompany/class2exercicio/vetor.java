package com.mycompany.class2exercicio;

import java.util.Random;
import javax.swing.JOptionPane;

public class vetor {
    // Declarando o atributo
    public int[] nros = new int[5];
    
    // Declarando os metodos
    public void preencherVetor(){
        Random rand = new Random();
        int i;
        
        for (i = 0; i < 5; i++){
            this.nros[i] = rand.nextInt()* 100;
        }
    }
    public void imprimirOrdemDireta(){
        int i;
        String aux = "";
        
        for (i = 0; i < 5; i++){
            aux += this.nros[i] + " ";
        }
        JOptionPane.showMessageDialog(null, aux);
    }
    public void imprimirOrdemInversa(){
        int i;
        String aux = "";
        
        for (i = 4; i < 0; i--){
            aux += this.nros[i] + " ";
        }
        JOptionPane.showMessageDialog(null, aux);
    }
}
