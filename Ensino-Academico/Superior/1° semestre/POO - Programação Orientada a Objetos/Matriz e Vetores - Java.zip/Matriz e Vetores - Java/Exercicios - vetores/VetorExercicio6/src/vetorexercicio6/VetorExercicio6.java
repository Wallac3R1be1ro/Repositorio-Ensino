/*
    Faça um programa que leia um vetor com quinze posiçoes para numeros inteiros.
    Depois da leitura, divida todos os seus elementos pelo maior valor do vetor.
    Mostre o vetor apos os calculos.

 */
package vetorexercicio6;

public class VetorExercicio6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
