
/*
 * Faça um programa que receba dois numeros inteiros, calcule e mostre a soma
 * desses numeros.
 */

package com.mycompany.exercicio1;

public class Exercicio1 {

    public static void main(String[] args) {
        // declarando as variaveis
        int nro1, nro2;
        int soma;
        
        // atribuindo valores as variaveis
        nro1 = 10;
        nro2 = 20;
        
        // executando a soma das variaveis e atribuindo 
        // a variavel soma o total
        soma = nro1 + nro2;
        
        
        // mostrando na tela o valor total da soma
        System.out.println("A soma total: " + soma);
        
    }
}




