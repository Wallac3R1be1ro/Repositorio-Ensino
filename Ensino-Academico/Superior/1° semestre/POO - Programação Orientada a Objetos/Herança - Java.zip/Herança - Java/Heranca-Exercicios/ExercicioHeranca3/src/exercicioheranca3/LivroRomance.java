/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicioheranca3;

public class LivroRomance extends Escritas {
    private String Autor;
    
    public void InserirLivroRomance(){
        super.setNome("Cidade de Papel");
        super.setTipo("Romance");
        this.Autor = "Livia";
    }
    public void MostrarLivroRomance(){
        System.out.println("Titulo Livro: " + super.getNome());
        System.out.println("Gênero Livro: " + super.getTipo());
        System.out.println("Autor Livro: " + this.Autor);
    }
}
