/*
 * Faça um programa que receba o salario bruto de um funcionario, e, usando 
   a tabela a seguir, calcule e mostre o valor a receber. Sabe-se que este 
   é composto pelo salario do funcionario acrescido de gratificação de grati-
   ficação e descontado o imposto de 7% sobre o salario sem gratificação.

    SALARIO                         GRATIFICAÇÃO
    Até R$ 3.500,00                     R$ 200,00
    R$ 3.500,00 e R$ 6.000,00           R$ 750,00
    R$ 6.000,00 e R$ 9.000,00           R$ 500,00
    Acima de R$ 9.000,00                R$ 350,00

 */

package com.mycompany.exemplo4condicional;

/**
 *
 * @author user1
 */
public class Exemplo4Condicional {

    public static void main(String[] args) {
        double salario;
        double gratificacao = 0;
        double imposto = 0;
        double salReceber = 0;
        
        // atribuindo o valor do salario a variavel
        salario = 4800;
        
        // calculando o valor do imposto e atribuindo o valor da gratificacao
        if (salario < 3500) {
            
            imposto = salario * 0.07;
            gratificacao = 200;
            
        } else if (salario >= 3500 && salario < 6000) {
            
            imposto = salario * 0.07;
            gratificacao = 750;
            
        } else if (salario >= 6000 && salario < 9000) {
            
            imposto = salario * 0.07;
            gratificacao = 500;
            
        } else {
            
            imposto = salario * 0.07;
            gratificacao = 350;
            
        }
        
        // calculando o salario a receber
        salReceber = (salario - imposto) + gratificacao;
        
        // imprimindo salario, gratificacao e imposto
        System.out.println("Salario..........: " + salario);
        System.out.println("Imposto..........: " + imposto);
        System.out.println("Gratificação.....: " + gratificacao);
        System.out.println("Salario a receber: " + salReceber);
    }
}
