
package exercicioheranca3;

public class Quadrinhos extends Escritas {
    private String Autor;
    
    public void InserirLivroQuadrinhos (){
        super.setNome("Naruto");
        super.setTipo("Aventura");
        this.Autor = "Kishimoto";
        
        
    }
    public void MotrarLivroQuadrinhos (){
        System.out.println("Titulo Livro: " + super.getNome());
        System.out.println("Genero Livro: " + super.getTipo());
        System.out.println("Autor do Livro: " + this.Autor);
    }
    
    
}
