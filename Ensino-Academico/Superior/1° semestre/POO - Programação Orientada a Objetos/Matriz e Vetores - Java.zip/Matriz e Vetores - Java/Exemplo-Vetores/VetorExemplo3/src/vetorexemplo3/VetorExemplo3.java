/*
    Faça um programa que preencha um vetor com 10 salarios de funcionarios, 
    calcule e mostre:

    a) O maior salario
    b) O menor salario
    c) A media geral dos salarios

 */
package vetorexemplo3;

import java.util.InputMismatchException;
import java.util.Scanner;

public class VetorExemplo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double [] sal = new double[10];
        double maior_sal, menor_sal, media_sal;
        int x;
        
        try {
            // carregando os salarios digitados pelo usuario
            for (x = 0; x < 10; x++) {
                System.out.print("Digite o salário: ");
                sal[x] = sc.nextDouble(); // guardando o salario no vetor
            }

            // respondendo os itens do exercício <a>, <b> e <c>
            maior_sal = 0;
            menor_sal = sal[0];
            media_sal = 0;
            for (x = 0; x < 10; x++) {
                media_sal += sal[x]; // somando os salarios
                
                if (sal[x] > maior_sal) {
                    maior_sal = sal[x];
                }
                if (sal[x] < menor_sal) {
                    menor_sal = sal[x];
                }                
            }
            System.out.println(""); // pula uma linha em branco
            System.out.println("Maior salário: R$ " + maior_sal);
            System.out.println("Menor salário: R$ " + menor_sal);
            System.out.println("Média dos salários: R$ " + String.format("%.2f" , (media_sal/10)));
            
            
        } catch (InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
    }
    
}
