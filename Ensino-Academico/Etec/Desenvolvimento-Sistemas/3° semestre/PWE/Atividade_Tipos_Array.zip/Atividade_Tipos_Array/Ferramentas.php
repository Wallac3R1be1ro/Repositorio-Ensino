<?php
echo "as ferramentas mais vendidas são:  " . "<br>";

$ferramentas = array('martelo','furadeira','serra','alicate','marreta','serrote');
for($posicao = 0; $posicao < count($ferramentas); $posicao++)
{
    echo $posicao . " é " . $ferramentas[$posicao] . "<br>";
}
//Nomes: Wallace, Joyce, Igor
?>


