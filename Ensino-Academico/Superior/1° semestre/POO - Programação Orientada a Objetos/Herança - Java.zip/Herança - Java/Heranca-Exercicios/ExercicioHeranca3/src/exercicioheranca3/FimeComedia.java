/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicioheranca3;

/**
 *
 * @author walla
 */
public class FimeComedia extends Filmes{
    private String Diretor;
    private String Nome;
    
    public void InserirDadosFilmeComedia(){
        this.Nome = "Gente Grande";
        this.Diretor = "Adam";
        super.setGênero("Comedia");
    }
    public void MostrarFilmeComedia(){
        System.out.println("Nome do filme: " + this.Nome);
                System.out.println("Gênero do filme: " + super.getGênero());
        System.out.println("Diretor do filme: " + this.Diretor);
    }
}
