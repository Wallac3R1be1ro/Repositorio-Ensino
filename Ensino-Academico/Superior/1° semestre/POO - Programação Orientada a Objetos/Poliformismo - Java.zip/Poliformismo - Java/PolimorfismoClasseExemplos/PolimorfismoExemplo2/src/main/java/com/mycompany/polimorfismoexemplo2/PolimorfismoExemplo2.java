

package com.mycompany.polimorfismoexemplo2;

public class PolimorfismoExemplo2 {

    public static void main(String[] args) {
        Conexao con = new DialUp();
        con.conectar();

        con = new AdSi();
        con.conectar();
        
    }
}


