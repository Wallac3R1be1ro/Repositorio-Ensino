﻿using Metodista.BancoDados;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.Principal
{
    public partial class Frm_Principal : Form
    {
        private ConexaoBancoDados db = new ConexaoBancoDados();

        public Frm_Principal(string usuario)
        {
            InitializeComponent();
        }

        private void lblSair_Click(object sender, EventArgs e)
        {
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            // fechando a tel (form) principal
            Frm_Principal.ActiveForm.Close();
        }
    }
}
