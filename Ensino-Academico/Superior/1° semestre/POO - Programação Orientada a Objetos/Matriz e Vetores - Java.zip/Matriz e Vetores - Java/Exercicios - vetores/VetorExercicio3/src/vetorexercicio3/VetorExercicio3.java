/*
    Faça um programa que preencha um vetor com quinze números, determine e mostre
    
    a) o maior numero e a posiçao por ele ocupada no vetor;
    b) o menor numero e a posiçao por ele ocupada no vetor.

 */
package vetorexercicio3;

public class VetorExercicio3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
