
package exercicioheranca3;

public class Filmes {
    private String Gênero;
    
    public void MostrarGenero(){
        System.out.println("Gênero do filme: " + this.Gênero);
    }

    public String getGênero() {
        return Gênero;
    }

    public void setGênero(String Gênero) {
        this.Gênero = Gênero;
    }
    
}
