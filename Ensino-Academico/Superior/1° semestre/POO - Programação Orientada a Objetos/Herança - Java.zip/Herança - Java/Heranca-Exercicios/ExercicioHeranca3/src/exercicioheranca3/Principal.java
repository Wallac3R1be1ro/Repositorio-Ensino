/*
    Construa uma hierarquia de classes para os seguintes tipos de obra:
    
    Romance, Livro de ficção, Livro de auto-ajuda, Gibi, Rock, Mpb,
    Filme ficção e Comedia.

    onde:

    - As classes LivroAutoAjuda, LivroRomance, LivroFiccao e Gibi derivam da 
      classe Escritas
    - As classes Rock e Mpb derivam da classe Musicais
    - As classes FimeComedia, FilmeFiccao derivam da classe Filmes.

 */
package exercicioheranca3;
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Rock rock = new Rock();
       Mpb mpb = new Mpb();
       FilmeFiccao ff = new FilmeFiccao();
       FimeComedia fc = new FimeComedia();
       LivroFiccao lf = new LivroFiccao();
       LivroAutoAjuda laa = new LivroAutoAjuda();
       Quadrinhos lq = new Quadrinhos();
       LivroRomance lr = new LivroRomance();
       
       System.out.println("-------------Gêneros de Musicas-------------");
       System.out.println("Musicas de Rock");
       rock.InserirDadosRock();
       rock.MostrarRock();
       System.out.println("");
       System.out.println("Musicas Mpb");
       mpb.InserirDadosMpb();
       mpb.MostrarMpb();
       System.out.println("");
       System.out.println("-------------Gêneros de Filmes-------------");
       System.out.println("Filme de Ficção");
       ff.InserirDadosFilmeFiccao();
       ff.MostrarFilmeFicção();
       System.out.println("");
       System.out.println("Filme de Comedia");
       fc.InserirDadosFilmeComedia();
       fc.MostrarFilmeComedia();
       System.out.println("");
       System.out.println("-------------Gêneros de Livros-------------");
       System.out.println("Livro de Ficcao");
       lf.InserirLivroFicao();
       lf.MostrarLivroFiccao();
       System.out.println("");
       System.out.println("Livro de AutoAjuda");
       laa.InserirLivroAutoAjuda();
       laa.MostrarLivroAutoAjuda();
       System.out.println("");
       System.out.println("Livro de Romance");
       lr.InserirLivroRomance();
       lr.MostrarLivroRomance();
       System.out.println("");
       System.out.println("Livro de Quadrinhos");
       lq.InserirLivroQuadrinhos();
       lq.MotrarLivroQuadrinhos();
       System.out.println("");
       
       
       
       
    }
    
}
