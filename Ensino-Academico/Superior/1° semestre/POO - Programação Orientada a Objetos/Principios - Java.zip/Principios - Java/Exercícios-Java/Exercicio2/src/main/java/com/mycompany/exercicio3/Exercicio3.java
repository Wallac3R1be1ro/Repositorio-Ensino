/*
 * Faça um programa que receba o salario de um funcionário, calcule e mostre
 * o novo salário, sabendo-se que este sofreu um aumento de 25%.
 */

package com.mycompany.exercicio3;

public class Exercicio3 {

    public static void main(String[] args) {
        // declarando as variaveis
        double salario, novoSalario;
        
        // atribuindo valores a variavel
        salario = 2000;
        
        // executando o aumento de 25%
        novoSalario = salario + (salario * 25/100);
        
        // imprimindo salario anterior novo salario apos aumento
        System.out.println("Salario Anterior: " + salario);
        System.out.println("Novo salario: " + novoSalario);
        
    }
}
