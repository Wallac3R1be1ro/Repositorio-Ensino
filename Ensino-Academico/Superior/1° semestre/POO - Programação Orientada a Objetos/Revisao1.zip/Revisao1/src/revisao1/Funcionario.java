
package revisao1;

public class Funcionario {
    public String nome;
    public double salBase;
    public int anoNasc;

    
    public void Exibe(){
    
    }
}
