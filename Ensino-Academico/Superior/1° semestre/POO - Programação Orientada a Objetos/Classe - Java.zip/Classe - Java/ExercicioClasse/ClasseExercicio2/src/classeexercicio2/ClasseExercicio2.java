/*
    Faça um projeto em Java que leia um vetor com cinco posiçoes para números
    reais e, depois, um código inteiro. Se o código for zero, finalize o
    programa:
    
    se for 1, mostre o vetor na ordem direta;
    se for 2, mostre o vetor na ordem inversa;
    se for 3, mostre o vetor na ordem crescente.

    Crie a classe necessaria para atender o projeto.

 */
package classeexercicio2;
import java.util.InputMismatchException;
import java.util.Scanner;
public class ClasseExercicio2 {
    
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        double[] reais = new double[5];
        int r;
        
        try{
            for (r = 0; r < 5; r++){
            System.out.print("Digite um número real: ");
            reais[r] = leia.nextDouble();
            
            }
            
        } catch (InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        System.out.println("Valor " + " é: " + reais);
    }
    
}
