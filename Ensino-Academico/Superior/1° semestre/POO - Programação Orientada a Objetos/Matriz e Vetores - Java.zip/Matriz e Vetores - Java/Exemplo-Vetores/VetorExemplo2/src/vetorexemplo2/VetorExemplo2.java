/*
    Faça um programa que preencha um vetor com os modelos de cinco carros
    (exemplos de modelos Fusca, Gol, Vectra, etc). Carregue outro vetor com o 
    consumo desses carros, isto é, quantos quilometros cada um deles faz com um 
    litro de combustivel, calcule e mostre:

    a) o modelo de carro mais economico
    b) quantos litros de combustivel cada um dos carros cadastrados consome
       para percorrer uma distancia de 1.000 quilometros.

*/
package vetorexemplo2;

import java.util.InputMismatchException;
import java.util.Scanner;

public class VetorExemplo2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String [] carro = new String[5];
        String aux;
        double [] consumo = new double[5];
        int x, qualCarro = 0;
        double menor_consumo, kmLitro;
        
        try {
            // digitando os modelos de carros pelo usuario
            for (x = 0; x < 5; x++) {
                System.out.print("Digite o modelo de carro: ");
                carro[x] = sc.nextLine(); // guardando no vetor o modelo
            }
            
            // digitando os consumos dos modelos respectivamente
            for (x = 0; x < 5; x++) {
                System.out.print("Digite o consumo do carro: " +carro[x] + ": ");
                consumo[x] = sc.nextDouble(); // guardando no vetor o consumo
            }
            
            // atendendo os itens do exercícios <a> e <b>
            menor_consumo = consumo[0]; // pega o primeiro consumo como base
            for (x = 0; x < 5; x++) {
                if (consumo[x] < menor_consumo) {
                    menor_consumo = consumo[x]; // guarda o menor consumo
                    qualCarro = x;              // quarda a posição
                }
                kmLitro = 1000 / consumo[x]; // calculando item <b> do exercicio
                
                // imprimindo os dados
                // montando a  descrição com a variavel aux
                aux = "\nO veículo " + carro[x] + ", consome ";
                aux += String.format("%.1f", kmLitro) + ", ";
                aux += "litro(s) de combustivel para percorrer 1000 km.";
                System.out.print( aux );
            }
            aux = "\nO veículo mais economico é " +carro[qualCarro] + ", ";
            aux += "consumo: " + menor_consumo + " km/l \n";
            System.out.print( aux );
            
            
        } catch(InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
