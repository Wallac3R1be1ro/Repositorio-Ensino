package com.luanewallace.principal;

import javax.swing.JOptionPane;

public class Usuario 
{
	// Atributos
	String nome, cpf;
	int senha;
	
    // Metodos
	public void cadastrar(String nome, String cpf, String senha) 
	{
		
		
		// 'Cadastrando' ;D
		JOptionPane.showMessageDialog(null, 
				"Usu�rio cadastrado!!! Seja bem-vindo " + nome + "!\n"
				+ "Nome: " +nome + "\n" + "CPF: " + cpf + "\n" + "Senha: " + senha);
	}
	
	public void calcTeste(double sal)
	{
		double novoSal = sal + (sal * 0.1);
		
		JOptionPane.showMessageDialog(null, "O novo sal�rio �: " + novoSal);
	}
	
	public void deletar() 
	{
		
	}
	
	public void alterarSenha()
	{
		
	}
}
