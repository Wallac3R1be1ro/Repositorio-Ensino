/*
 * Criar um programa que o usuario vai digitar um nro qq
    e o programa deve verificar se o nro digitado é par ou ímpar.
 */
package com.mycompany.exemplo.par_impar;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExemploPar_Impar {

    public static void main(String[] args) {

        int nro;
        Scanner sc = new Scanner(System.in);
        
        try{
            System.out.println("Digite um nro qq: ");
            nro = sc.nextInt();
            
            if(nro % 2 == 0){
                System.out.println("O número digitado é par!");
            }else{
                System.out.println("O número digitado é impar!");
            }

        }catch(InputMismatchException e) {
            System.out.println("Erro na digitação!");
        }
    }
}
