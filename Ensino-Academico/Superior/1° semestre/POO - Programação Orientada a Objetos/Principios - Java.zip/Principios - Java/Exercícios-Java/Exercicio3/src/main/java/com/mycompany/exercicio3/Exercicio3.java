package com.mycompany.exercicio3;
/**
 * Calculando base quadrado
 */
public class Exercicio3 {

    public static void main(String[] args) {
        double Area, Base, Altura;
        
        Base = 5;
        Altura= 5;
        Area = (Base * Altura) / 2;
        System.out.println("Triangulo: " + Area);
    }
}
