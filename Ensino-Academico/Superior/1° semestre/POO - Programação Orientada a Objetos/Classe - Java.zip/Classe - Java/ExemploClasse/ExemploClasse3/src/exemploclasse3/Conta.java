
package exemploclasse3;

public class Conta {
    // declaração dos atributos da classe
    public String nomeTitular;
    public String nroConta;
    public double limite;
    public double saldo;
    
    // métodos da classe
    public void Depositar(double valor) {
        this.saldo += valor;
        System.out.println("Deposito efetuado: R$ " + valor);
    }
    public boolean Sacar(double valor) {
        double nsaldo = this.limite + this.saldo;
        
        if (nsaldo >= valor) {
            this.saldo -= valor;
            System.out.println("Saque efetuado: R$ " + valor);
            return true;
        }
        System.out.println("Saldo insuficiente para o saque: R$ " + valor);
        return false;
    }
}


