/*
 * Faça um programa que calcule e mostre a area de um triangulo.
 * Sabe-se que: Area = (base * altura) / 2.
 */

package com.mycompany.exercicio6;

/**
 *
 * @author clsma
 */
public class Exercicio6 {

    public static void main(String[] args) {
        
    }
}
