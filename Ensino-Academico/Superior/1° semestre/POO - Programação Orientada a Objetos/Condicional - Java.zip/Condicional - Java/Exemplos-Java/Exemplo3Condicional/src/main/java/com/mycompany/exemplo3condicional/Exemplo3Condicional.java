/*
 * O preço, ao consumidor, de um carro novo é a soma do custo de fabrica
   com a porcentagem do distribuidor e com os impostos, ambos aplicados ao 
   custo de fabrica. As porcentagens encontra-se na tabela a seguir. Faça
   um programa que receba o custo de fabrica de um carro e mostre o preço 
   ao consumidor.

    CUSTO DE FABRICA                    % DO DISTRIBUIDOR       % DOS IMPOSTOS
    Até R$ 12.000,00                            5                   isento
    Entre R$ 12.000,00 e R$ 25.000,00           10                  15
    Acima de R$ 25.000,00                       15                  20

 */
package com.mycompany.exemplo3condicional;

/**
 *
 * @author user1
 */
public class Exemplo3Condicional {

    public static void main(String[] args) {
        double custoAuto;
        double custoDistribuidor = 0;
        double valorImposto = 0;
        double valorTotal;
        
        // atribuindo o valor do custo automovel
        custoAuto = 14500;
        
        // fazendo o calculo distribuidor e impostos
        if (custoAuto < 12000) {
            
            custoDistribuidor = custoAuto * 0.05;
            valorImposto = 0;
            
        } else if (custoAuto >= 12000 && custoAuto < 25000) {
            
            custoDistribuidor = custoAuto * 0.10;
            valorImposto = custoAuto * 0.15;
            
        } else if (custoAuto >= 25000) {
            
            custoDistribuidor = custoAuto * 0.15;
            valorImposto = custoAuto * 0.20;
            
        }
        
        // calculando o preço final 
        valorTotal = custoAuto + custoDistribuidor + valorImposto;
        
        
        System.out.println("Custo de fabrica..: R$ " + custoAuto);
        System.out.println("Custo Distribuidor: R$ " + custoDistribuidor);
        System.out.println("Custo de impostos.: R$ " + valorImposto);
        System.out.println("Custo Total.......: R$ " + valorTotal);
    }
}
