/*
    Crie uma classe com os seguintes atributos de um analista de sistemas: 
    - Nome, 
    - ano de nascimento, 
    - salário base, 
    - se tem mestrado, 
    - meses de experiência.

    Crie uma classe com os seguintes atributos de um programador:
    - Tem graduação, 
    - salário base, 
    - se tem certificação Java, 
    - nome, 
    - sexo, 
    - ano de nascimento.

    Tanto os programadores quantos os analistas de sistemas são tipos de 
    funcionário.

    Aplique o conceito de encapsulamento e de herança.

    Na classe do método main, instancie um objeto do tipo programador e 
    chame o método que exibe todas as informações cadastrais. 
    
    Cada classe possui um método chamado “exibe()” que dá um "System.out.println"
    nos campos da classe; apenas as classes filhas podem executar o método 
    “exibe()” da classe mãe.

 */
package exercicioheranca1;

public class Principal {

    public static void main(String[] args) {
        
    }
    
}
