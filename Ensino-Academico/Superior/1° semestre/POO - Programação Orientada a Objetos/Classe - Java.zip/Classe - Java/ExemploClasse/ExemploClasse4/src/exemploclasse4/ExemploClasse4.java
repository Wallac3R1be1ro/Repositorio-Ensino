/*
    Faça um projeto em Java contendo uma classe que retorne 1 se o número 
    digitado pelo usuario for positivo ou 0 se for negativo.

 */
package exemploclasse4;

import java.util.Random;

public class ExemploClasse4 {

    public static void main(String[] args) {
        // declaração da classe
        verificaNroDigitado verifica = new verificaNroDigitado();
        Random rand = new Random();
        
        // declaração da variavel primitiva
        int i;
        
        // gerando 20 nros quaisquer pelo for
        for (i = 0; i < 20; i++) {
            verifica.nro = rand.nextInt(200); // atribuindo o valor ao atributo
            
            if (verifica.nro % 10 != 0) {
                verifica.nro *= -1;    // mudando o sinal do valor do atributo
            }
            
            // verificando se o nro gerado é positivo ou negativo
            if (verifica.VerificaNro() == 1) {
                System.out.println("Nro: " + verifica.nro + " positivo");
            } else {
                System.out.println("Nro: " + verifica.nro + " negativo");  
            }
        }
    }
    
}
