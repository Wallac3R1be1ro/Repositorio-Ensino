package com.luanewallace.principal;

import javax.swing.JOptionPane;

public class Principal 
{

	public static void main(String args[]) 	
	{
		
		// Recebendo o valor do usu�rio
		String nome = JOptionPane.showInputDialog("Nome: ");
		
		String cpf = JOptionPane.showInputDialog("CPF: ");
		
		String senha = JOptionPane.showInputDialog("Senha: ");
		
		double salario = Double.parseDouble(JOptionPane.showInputDialog("Sal�rio: "));
		
		// Instanciando a classe Usu�rio
		Usuario user = new Usuario();
		user.cadastrar(nome, cpf, senha);
		user.calcTeste(1000);
	}
	
}
