/*
Crie uma classe com os seguintes atributos de um analista de sistemas: 
Nome, ano de nascimento, salário base, tem mestrado, meses de experiência.

Crie uma classe com os seguintes atributos de um programador:
Tem graduação, salário base, tem certificação Java, nome, sexo, ano de 
nascimento.

Tanto os programadores quantos os analistas de sistemas são tipos de 
funcionário.

Aplique o conceito de encapsulamento e de herança.

Na classe do método main, instancie um objeto do tipo programador e chame 
o método que exibe todas as informações cadastrais. Cada classe possui um método 
chamado “exibe()” que dá um “System.out.println” nos campos da classe; apenas 
as classes filhas podem executar o método “exibe()” da classe mãe.

*/
package revisao1;

import javax.swing.JOptionPane;

public class Principal {

    public static void main(String[] args) {
        Programador prg;
        // instancia da classe
        prg = new Programador(
                true,
                9580,
                true,
                "Carlos Mattos",
                'M',
                1969
        );
        
        String[] aux = new String[8];
        aux = prg.Exibe(true).split(";");
        JOptionPane.showMessageDialog(null, aux);
        
        prg.Exibe();
    }
    
}
