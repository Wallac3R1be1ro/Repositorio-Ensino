
package exemploheranca3;

public class FuncionarioAutenticavel extends Funcionario {
    
    public FuncionarioAutenticavel(String nome, String celular, String email) {
        super(nome, celular, email);
    }
    
}
