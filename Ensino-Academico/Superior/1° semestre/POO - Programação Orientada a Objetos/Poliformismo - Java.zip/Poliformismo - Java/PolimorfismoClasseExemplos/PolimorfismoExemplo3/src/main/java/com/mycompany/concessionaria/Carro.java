
package com.mycompany.concessionaria;

public interface Carro {
    
    public double AumentoAnual();
    
    public void ApresentaCarro();
    
}
