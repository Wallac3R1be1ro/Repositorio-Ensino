/*
    Faça um projeto em Java com a(s) classe(s) necessaria para atender a seguinte
    situação. Recea o total das vendas de cada vendedor de uma loja e armazene-as
    em um vetor. Receba também o percentual de comissao a que cada vendedor tem 
    direito e armazene-os em outro vetor. Receba os nomes desses vendedores e 
    armazene-os em um terceiro vetor. Existem apenas dez vendedores na loja.
    
    Calcule e mostre:

    a) um relatorio com os nomes dos vendedores e os valores a receber referentes
       a comissao.
    b) o total das vendas de todos os vendedores.
    c) o maior valor a receber e o nome de quem o receberá.
    d) o menor valor a receber e o nome de quem o receberá.

 */
package classeexercicio5;

//import java.util.InputMismatchException;
//import java.util.Scanner;

public class ClasseExercicio5 {

    public static void main(String[] args) {
      //Scanner sc = new Scanner(System.in);
      String[] vendedores = new String[10];
      //-------Lista de Vendedores-------------------------
      vendedores[0] = "Wallace";
      vendedores[1] = "Vitor";
      vendedores[2] = "Giulia";
      vendedores[3] = "Thamara";
      vendedores[4] = "Erick";
      vendedores[5] = "Fabrício";
      vendedores[6] = "Joyce";
      vendedores[7] = "Jose";
      vendedores[8] = "Luan";
      vendedores[9] = "Douglas";
      //---------------------------------------------------
      //-------Lista de Quantidade de Vendas---------------
      double[] QtdVendas = new double[10];
      //int[] total = new int[10];
      double resultado;
      double comissao;
      int menor, maior;
      int x;
      QtdVendas[0] = 510;
      QtdVendas[1] = 410;
      QtdVendas[2] = 640;
      QtdVendas[3] = 110;
      QtdVendas[4] = 733;
      QtdVendas[5] = 210;
      QtdVendas[6] = 710;
      QtdVendas[7] = 910;
      QtdVendas[8] = 577;
      QtdVendas[9] = 590;
//---------------------------------------------------
      System.out.println();
        System.out.println("Quantidade de Vendas");
      System.out.println();
//---------------------------------------------------     
      System.out.println
        ("Vendedor(a): " + vendedores[0] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[0]);
      System.out.println
        ("Vendedor(a): " + vendedores[1] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[1]);
      System.out.println
        ("Vendedor(a): " + vendedores[2] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[2]);
      System.out.println
        ("Vendedor(a): " + vendedores[3] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[3]);
      System.out.println
        ("Vendedor(a): " + vendedores[4] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[4]);
      System.out.println
        ("Vendedor(a): " + vendedores[5] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[5]);
      System.out.println
        ("Vendedor(a): " + vendedores[6] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[6]);
      System.out.println
        ("Vendedor(a): " + vendedores[7] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[7]);
      System.out.println
        ("Vendedor(a): " + vendedores[8] + ", acumulou em seus produtos vendidos o valor de "  + "R$" + QtdVendas[8]);
      System.out.println
        ("Vendedor(a): " + vendedores[9] + ", acumulou em seus produtos vendidos o valor de " + "R$" + QtdVendas[9]);
//---------------------------------------------------  
      System.out.println();
        System.out.println("Comissão de vendedores");
      System.out.println();     
//---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[0] * 0.10;
       resultado = comissao + QtdVendas[0];
       System.out.println
       ("Vendedor(a): " + vendedores[0] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[1] * 0.10;
       resultado = comissao + QtdVendas[1];
       System.out.println
       ("Vendedor(a): " + vendedores[1] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[2] * 0.10;
       resultado = comissao + QtdVendas[2];
       System.out.println
       ("Vendedor(a): " + vendedores[2] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[3] * 0.10;
       resultado = comissao + QtdVendas[3];
       System.out.println
       ("Vendedor(a): " + vendedores[3] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[4] * 0.10;
       resultado = comissao + QtdVendas[4];
       System.out.println
       ("Vendedor(a): " + vendedores[4] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[5] * 0.10;
       resultado = comissao + QtdVendas[5];
       System.out.println
       ("Vendedor(a): " + vendedores[5] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[6] * 0.10;
       resultado = comissao + QtdVendas[6];
       System.out.println
       ("Vendedor(a): " + vendedores[6] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[7] * 0.10;
       resultado = comissao + QtdVendas[7];
       System.out.println
       ("Vendedor(a): " + vendedores[7] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[8] * 0.10;
       resultado = comissao + QtdVendas[8];
       System.out.println
       ("Vendedor(a): " + vendedores[8] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       //---------------------------------------------------------------------------------------------------
       comissao = QtdVendas[9] * 0.10;
       resultado = comissao + QtdVendas[9];
       System.out.println
       ("Vendedor(a): " + vendedores[9] + ", recebeu de comissão 10%, em seu valor total: " + "R$" + resultado);
       
       //Tentativa de exibir nota menor e maior, sem sucesso.
       /*for(x = 0; x < 10; x++){
           if(QtdVendas[x++] <= menor){
               System.out.println
                ("Menor valor: " + QtdVendas[x++]);
           }
       }
      for(x = 0; x < 10; x++){
           if(QtdVendas[x++] > maior){
               System.out.println
                ("Maior valor: " + QtdVendas[x++]);
           }
       }*/
   
    
    }
}
