/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicioheranca3;

public class Rock extends Musicais{
    private String Banda;
    
    public void InserirDadosRock(){
        super.setNome("Shadowns of Rock");
        this.Banda = "Slimpinhos";
        super.setGenero("Rock");
    }
    public void MostrarRock(){
        System.out.println("Nome da Música: " + super.getNome());
        System.out.println("Nome da Banda: " + this.Banda);
        System.out.println("Gênero da Música: " + super.getGenero());
    }
    

}
