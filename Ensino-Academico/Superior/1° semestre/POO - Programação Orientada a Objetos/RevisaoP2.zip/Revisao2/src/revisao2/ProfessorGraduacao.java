
package revisao2;

public class ProfessorGraduacao {
    // atributos da classe
    public String matricula;
    public String nome;
    public double salBruto;
    public int qtdeDisc;
    
    // construtor da classe
    public ProfessorGraduacao(String matricula, String nome, double salBruto, int qtdeDisc) {
        this.matricula = matricula;
        this.nome = nome;
        this.salBruto = salBruto;
        this.qtdeDisc = qtdeDisc;
    }
    
}
