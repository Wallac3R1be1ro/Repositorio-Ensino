/*
    Faça um programa que receba o nome de cinco produtos e seus respectivos
    preços, calcule e mostre:
    
    a) a quantidade de produtos com preço inferior a R$ 500,00;
    b) o nome dos produtos com preço entre R$ 500,00 e R$ 1000,00;
    c) a media dos preços dos produtos com preço superior a R$ 1000,00.

 */
package vetorexercicio1;
import java.util.InputMismatchException;
import java.util.Scanner;

public class VetorExercicio1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        Scanner scval = new Scanner(System.in);
		//String[] produtos = new String[5];
                //double[] preco = new double[5];
                String produto1, produto2, produto3, produto4, produto5;
                double valor1, valor2, valor3, valor4, valor5;
		double preco_inferior, preco_superior;
                
                preco_inferior = 500;
                preco_superior = 1000;
                
                System.out.print("Digite um produto: ");
                produto1=scan.nextLine();
                //------------------------------------------------
                System.out.print("Digite o preço do " + produto1 + ": ");
                valor1=scval.nextDouble();
                
                System.out.print("Digite um produto: ");
                produto2=scan.nextLine();
                //------------------------------------------------
                System.out.print("Digite o preço do " + produto2 + ": ");
                valor2=scval.nextDouble();
                
                System.out.print("Digite um produto: ");
                produto3=scan.nextLine();
                //------------------------------------------------
                System.out.print("Digite o preço do " + produto3 + ": ");
                valor3=scval.nextDouble();
                
                System.out.print("Digite um produto: ");
                produto4=scan.nextLine();
                //------------------------------------------------
                System.out.print("Digite o preço do " + produto4 + ": ");
                valor4=scval.nextDouble();
                
                System.out.print("Digite um produto: ");
                produto5=scan.nextLine();
                //------------------------------------------------
                System.out.print("Digite o preço do " + produto5 + ": ");
                valor5=scval.nextDouble();
                
                System.out.println("-----------------------------------------");
                // VALORES SÃO MENORES QUE R$500?
                System.out.println("-----------------------------------------");
                System.out.println("Valores inferiores a R$500");
                if(valor1 < preco_inferior){
                    System.out.println("Valor do produto " + produto1 + ": R$" + valor1 + ", é inferior a R$500.");
                }
                if(valor2 < preco_inferior){
                    System.out.println("Valor do produto " + produto2 + ": R$" + valor2 + ", é inferior a R$500.");
                }
                if(valor3 < preco_inferior){
                    System.out.println("Valor do produto " + produto3 + ": R$" + valor3 + ", é inferior a R$500.");
                }
                if(valor4 < preco_inferior){
                    System.out.println("Valor do produto " + produto4 + ": R$" + valor4 + ", é inferior a R$500.");
                }
                if(valor5 < preco_inferior){
                    System.out.println("Valor do produto " + produto5 + ": R$" + valor5 + ", é inferior a R$500.");
                }
                    
                // VALORES SÃO MAIORES QUE R$500?
                System.out.println("-----------------------------------------");
                System.out.println("Valores superiores a R$1000");
                System.out.println("-----------------------------------------");
                if(valor1 > preco_superior){
                    System.out.println("Valor do produto " + produto1 + ": R$" + valor1 + ", é superior a R$1,000.");
                }
                if(valor2 > preco_superior){
                    System.out.println("Valor do produto " + produto2 + ": R$" + valor2 + ", é superior a R$1,000.");
                }
                if(valor3 > preco_superior){
                    System.out.println("Valor do produto " + produto3 + ": R$" + valor3 + ", é superior a R$1,000.");
                }
                if(valor4 > preco_superior){
                    System.out.println("Valor do produto " + produto4 + ": R$" + valor4 + ", é superior a R$1,000.");
                }
                if(valor5 > preco_superior){
                    System.out.println("Valor do produto " + produto5 + ": R$" + valor5 + ", é superior a R$1,000.");
                }
                
                
                
                
                
               
        }
		
		
		
		
		
		
       
    }
