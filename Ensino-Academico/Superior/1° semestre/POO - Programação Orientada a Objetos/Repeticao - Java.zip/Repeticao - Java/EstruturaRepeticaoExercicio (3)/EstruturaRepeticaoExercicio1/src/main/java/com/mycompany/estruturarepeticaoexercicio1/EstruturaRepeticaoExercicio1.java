/*
    Faça um programa que receba um valor de N inteiro e positivo, calcule e 
    mostre o valor de E, conforme a formula a seguir:

        E = 1 + 1/1! + 1/2! + 1/3! + ... + 1/N!

 */

package com.mycompany.estruturarepeticaoexercicio1;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio1 {

    public static void main(String[] args) {
        
    }
}
