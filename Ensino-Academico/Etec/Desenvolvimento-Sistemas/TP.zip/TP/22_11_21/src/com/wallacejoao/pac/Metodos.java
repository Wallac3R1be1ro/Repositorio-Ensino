package com.wallacejoao.pac;

public class Metodos 
{
	 public int metodo1(int a,int b) 
	 {
	     int soma = a+b;
	     return soma;
	 }
	 
	 
	 public void metodo2() 
	 {
		 
	      	
		 
	 }
	
	

}
