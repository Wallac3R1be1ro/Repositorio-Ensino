
package exemploheranca3;

public class Diretor extends FuncionarioAutenticavel {
    
    public Diretor(String nome, String celular, String email) {
        super(nome, celular, email);
    }
    
}
