/*
    Faça um programa que receba dez numeros, calcule e mostre a soma dos 
    numeros pares e dos numeros primos.

 */

package com.mycompany.estruturarepeticaoexercicio7;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio7 {

    public static void main(String[] args) {
  
    }
}
