
package exemploclasse4;

public class verificaNroDigitado {
    // declaração do atributo da classe
    public int nro;
    
    
    // declaração do método da classe
    public int VerificaNro() {
        
        if (this.nro < 0) {
            return 0;
        } else {
            return 1;
        }
    }
}
