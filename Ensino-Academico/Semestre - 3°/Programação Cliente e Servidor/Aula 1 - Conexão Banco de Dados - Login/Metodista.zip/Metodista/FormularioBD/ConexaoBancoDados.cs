﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Metodista.FormularioBD
{
    public class ConexaoBancoDados
    {
        // Objeto de conexão com banco
        public MySqlConnection conn = null;

        // Objeto de transação com o banco de dados
        public MySqlTransaction transaction = null;

        // Objeto de comando do banco de dados
        public MySqlCommand cmd = null;

        // Construtor da classe
        public ConexaoBancoDados() 
        {
            
        }

        // Metodo de conexao mesmo
        public void ConectarBancoDados()
        {
            // Configuração
            string data_source = "datasource=127.0.0.1;username='root';password='';database='metodista';" +
                                  "Allow Zero Datetime = true";
                                  ;
        }
    }
}
