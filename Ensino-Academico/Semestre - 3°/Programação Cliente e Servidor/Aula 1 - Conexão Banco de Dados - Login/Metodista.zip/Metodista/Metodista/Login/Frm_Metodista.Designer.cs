﻿namespace Metodista.Login
{
    partial class Frm_Metodista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Metodista));
            this.label1 = new System.Windows.Forms.Label();
            this.bEntrar = new System.Windows.Forms.Button();
            this.bSair = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tUsuario = new System.Windows.Forms.TextBox();
            this.tSenha = new System.Windows.Forms.TextBox();
            this.bSenha = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(80, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(223, 50);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login Aluno";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bEntrar
            // 
            this.bEntrar.BackColor = System.Drawing.Color.Transparent;
            this.bEntrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bEntrar.FlatAppearance.BorderSize = 0;
            this.bEntrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bEntrar.Image = ((System.Drawing.Image)(resources.GetObject("bEntrar.Image")));
            this.bEntrar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bEntrar.Location = new System.Drawing.Point(82, 243);
            this.bEntrar.Name = "bEntrar";
            this.bEntrar.Size = new System.Drawing.Size(92, 41);
            this.bEntrar.TabIndex = 2;
            this.bEntrar.Text = "Entrar";
            this.bEntrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bEntrar.UseVisualStyleBackColor = false;
            this.bEntrar.Click += new System.EventHandler(this.bEntrar_Click);
            // 
            // bSair
            // 
            this.bSair.BackColor = System.Drawing.Color.Transparent;
            this.bSair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bSair.FlatAppearance.BorderSize = 0;
            this.bSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSair.Image = ((System.Drawing.Image)(resources.GetObject("bSair.Image")));
            this.bSair.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bSair.Location = new System.Drawing.Point(198, 243);
            this.bSair.Name = "bSair";
            this.bSair.Size = new System.Drawing.Size(80, 41);
            this.bSair.TabIndex = 3;
            this.bSair.Text = "Sair";
            this.bSair.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bSair.UseVisualStyleBackColor = false;
            this.bSair.Click += new System.EventHandler(this.bSair_Click);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(17, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 36);
            this.label2.TabIndex = 4;
            this.label2.Text = "Usuário:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 36);
            this.label3.TabIndex = 5;
            this.label3.Text = "Senha:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Location = new System.Drawing.Point(2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(103, 85);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // tUsuario
            // 
            this.tUsuario.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tUsuario.Location = new System.Drawing.Point(101, 129);
            this.tUsuario.Name = "tUsuario";
            this.tUsuario.Size = new System.Drawing.Size(237, 20);
            this.tUsuario.TabIndex = 8;
            // 
            // tSenha
            // 
            this.tSenha.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tSenha.Location = new System.Drawing.Point(101, 185);
            this.tSenha.Name = "tSenha";
            this.tSenha.PasswordChar = '*';
            this.tSenha.Size = new System.Drawing.Size(237, 20);
            this.tSenha.TabIndex = 9;
            // 
            // bSenha
            // 
            this.bSenha.BackColor = System.Drawing.Color.Transparent;
            this.bSenha.Cursor = System.Windows.Forms.Cursors.Help;
            this.bSenha.FlatAppearance.BorderSize = 0;
            this.bSenha.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bSenha.Image = ((System.Drawing.Image)(resources.GetObject("bSenha.Image")));
            this.bSenha.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bSenha.Location = new System.Drawing.Point(114, 308);
            this.bSenha.Name = "bSenha";
            this.bSenha.Size = new System.Drawing.Size(146, 41);
            this.bSenha.TabIndex = 10;
            this.bSenha.Text = "Esqueceu a senha?";
            this.bSenha.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.bSenha.UseVisualStyleBackColor = false;
            this.bSenha.Click += new System.EventHandler(this.bSenha_Click);
            // 
            // Frm_Metodista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(366, 450);
            this.Controls.Add(this.bSenha);
            this.Controls.Add(this.tSenha);
            this.Controls.Add(this.tUsuario);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bSair);
            this.Controls.Add(this.bEntrar);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Frm_Metodista";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Formulário Academico";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bEntrar;
        private System.Windows.Forms.Button bSair;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox tUsuario;
        private System.Windows.Forms.TextBox tSenha;
        private System.Windows.Forms.Button bSenha;
    }
}