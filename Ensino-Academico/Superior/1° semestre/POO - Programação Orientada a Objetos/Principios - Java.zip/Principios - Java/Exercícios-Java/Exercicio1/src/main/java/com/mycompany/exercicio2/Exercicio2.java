/*
 * Faça um programa que receba tres notas de alunos, calcule e mostre a media
 * dessas notas.
 */

package com.mycompany.exercicio2;

public class Exercicio2 {

    public static void main(String[] args) {
        // declarando as variaveis
        double nota1, nota2, nota3;
        double media;
        
        // adicionando valores as variaveis
        nota1 = 7.5;
        nota2 = 4.5;
        nota3 = 9.0;
        
        // fazendo a media das notas
        media = (nota1 + nota2 + nota3) / 3;
        
        // Mostrando a media final na tela
        System.out.println("Media final: " + media);
        
        
    }
}


