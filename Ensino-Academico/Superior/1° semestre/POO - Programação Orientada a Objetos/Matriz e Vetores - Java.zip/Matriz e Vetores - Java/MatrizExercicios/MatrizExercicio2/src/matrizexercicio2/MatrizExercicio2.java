/*
    Crie um programa que preencha uma matriz 2 x 4 com números inteiros, calcule
    e mostre:

    a) a quantidade de elementos entre 12 e 20 em cada linha;
    b) a media dos elementos pares da matriz.

 */
package matrizexercicio2;

public class MatrizExercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
