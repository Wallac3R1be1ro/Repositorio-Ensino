
package exemploheranca3;

public class Funcionario {
    public String nome;
    public String celular;
    public String email;
    
    // construtor da classe Funcionario
    public Funcionario(String nome, String celular, String email) {    
        this.nome = nome;
        this.celular = celular;
        this.email = email;
    }

    // metodo da classe
    public String ImprimeDados() {
        String aux = "";
        
        aux += "\nDados pessoais\n\n";
        aux += "Nome: "     + this.nome      + "\n";
        aux += "Celular: "  + this.celular   + "\n";
        aux += "E-mail: "   + this.email     + "\n\n";
        return aux;
    }
}
