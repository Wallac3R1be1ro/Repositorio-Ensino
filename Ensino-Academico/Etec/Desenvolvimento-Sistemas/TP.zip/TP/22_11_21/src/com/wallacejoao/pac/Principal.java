package com.wallacejoao.pac;

import javax.swing.JOptionPane;


public class Principal {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Metodos met = new Metodos();
		
		JOptionPane.showMessageDialog(
				null, met.metodo1(2,6));
    }

	
}
