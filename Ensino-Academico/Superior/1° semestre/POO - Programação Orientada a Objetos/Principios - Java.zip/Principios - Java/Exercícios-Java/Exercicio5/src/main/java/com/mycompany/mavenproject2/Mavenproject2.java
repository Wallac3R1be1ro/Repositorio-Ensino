/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mavenproject2;

import java.util.Scanner;

/**
 *
 * @author clsma
 */
public class Mavenproject2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int i;
        System.out.println("Digite um número qualquer: ");
        i = sc.nextInt();
        if (i % 2 == 0) 
            System.out.println("O número digitado é par!");
        else
            System.out.println("O número digitado é impar!");
    }
}
