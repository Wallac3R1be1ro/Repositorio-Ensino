/*
    Faça um programa que receba um número N e que indique quantos valores
    inteiros e positivos devem ser lidos a seguir. Para cada número lido, 
    mostre uma tabela contendo o valor lido e o fatorial desse valor.
 */

package com.mycompany.estruturarepeticaoexercicio2;

/**
 *
 * @author clsma
 */
public class EstruturaRepeticaoExercicio2 {

    public static void main(String[] args) {
      
    }
}
