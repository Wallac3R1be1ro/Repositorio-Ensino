/*
    Faça um projeto em Java que receba dois números inteiros e positivos. A classe
    deve retornar a soma dos N números inteiros existentes entre eles.
 */
package exemploclasse5;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExemploClasse5 {

    public static void main(String[] args) {
        somaIntervalo soma = new somaIntervalo();
        Scanner sc = new Scanner(System.in);
                
        int i, nro1, nro2;
        
        try {
            System.out.print("Digite o primeiro nro: ");
            nro1 = sc.nextInt();
            
            System.out.print("Digite o segundo nro: ");
            nro2 = sc.nextInt();
            
            // atribuindo o nro digitado ao atributo da classe
            soma.setNro1(nro1);
            soma.setNro2(nro2);
            
            // apresentando a soma entre eles
            System.out.println("Soma: " + soma.somarIntervalo());
            
        } catch(InputMismatchException ex) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
