
package exemploclasse5;

public class somaIntervalo {
    // declarando os atributos da classe
    private int nro1;
    private int nro2;
    private int soma;
    
    // declarando o metodo da classe
    public int somarIntervalo() {
        int i;
        
        this.soma = 0;
        for (i = nro1+1; i <= nro2; i++) {
            this.soma += i;
        }
        return this.soma;
    }
    
    // declarando os metodos dos atributos get e set
    public int getNro1() {
        return nro1;
    }
    public void setNro1(int nro1) {
        this.nro1 = nro1;
    }
    public int getNro2() {
        return nro2;
    }
    public void setNro2(int nro2) {
        this.nro2 = nro2;
    }
    public int getSoma() {
        return soma;
    }
    public void setSoma(int soma) {
        this.soma = soma;
    }
    
}
