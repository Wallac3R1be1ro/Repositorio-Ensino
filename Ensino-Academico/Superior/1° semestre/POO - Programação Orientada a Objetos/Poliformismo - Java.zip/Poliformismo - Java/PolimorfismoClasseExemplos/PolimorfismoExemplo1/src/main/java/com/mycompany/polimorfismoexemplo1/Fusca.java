
package com.mycompany.polimorfismoexemplo1;

public class Fusca implements Carro {

    @Override
    public void acelerar() {
        System.out.println("Fusca tentando acelerar…");        
    }
    
}


