
package com.mycompany.concessionaria;

public class Golf implements Carro {
    public double valorCarro;
    
    public Golf() {
        this.valorCarro = 180000;
    }
        
    @Override
    public double AumentoAnual() {
        this.valorCarro *= 1.20;
        return this.valorCarro;
    }

    @Override
    public void ApresentaCarro() {
        System.out.println("Valor do Golf: R$ " + String.format("%.2f", this.valorCarro));
    }
    
}
