/*
    Faça um programa que receba:

    - as notas de 15 alunos em cinco provas diferentes e armazene-as em uma 
      matriz 15 x 5;
    - os nomes dos 15 alunos e armazene-os em um vetor de 15 posiçoes.

    O programa deverá calcular e mostrar:

    a) para cada aluno, o nome, a media aritmetica das cinco provas e a situação
       (6 ou acima - aprovado,0 a 3 - reprovado ou 4 a 6 - exame);
    b) a media da classe.
 */
package matrizexercicio4;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MatrizExercicio4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double [][] notas = new double[5][5];
        double menor, media, maior;
        String[] nomes;
        nomes = new String[5];
        int x, exame = 0, aprov = 0, y = 0;
        
        try {
            
            // digitando as notas dos 10 alunos
            for (x = 0; x < 5; x++) {
                for (y = 0; y < 5; y++) {
                    System.out.println("Digite o nome do aluno(a): ");
                    nomes[i] = new Scanner(System.in).nextLine();
                }
                for (y = 0; y < 5; y++) {
                    System.out.print("Digite a " +(y+1) + " nota: ");
                    notas[x][y] = sc.nextDouble();
                }
            }
            
            // mostrandos os alunos e suas notas e também a menor nota de cada aluno
            for (x = 0; x < 5; x++) {
                
                menor = notas[x][0];
                media = notas[x][0];
                maior = notas[x][0];
                System.out.println("\n" + x + " aluno");
                System.out.print("Notas: ");
                
                /*if (notas[x][y] < 3){
                    menor = notas[x][y];
                    System.out.println(" - Menor nota: " + menor);
                }
                if (notas[x][y] < 5){
                    media = notas[x][y];
                    System.out.println(" - Media nota: " + media);
                }
                if (notas[x][y] >= 6){
                    maior = notas[x][y];
                    System.out.println(" - Maior nota: " + maior);
                }*/
                for (y = 0; y < 3; y++) {
                    System.out.print(" " + notas[x][y]);
                    if (notas[x][y] < menor) {
                        menor = notas[x][y];
                        System.out.println("está reprovado!");
                    }
                }
                for (exame = 0; exame < 5; exame++) {
                    System.out.print(" " + notas[x][y]);
                    if (notas[x][y] < media) {
                        media = notas[x][y];
                        System.out.println("está em exame!");
                    }
                }
                for (aprov = 0; aprov >= 6; aprov++) {
                    System.out.print(" " + notas[x][y]);
                    if (notas[x][y] >= maior) {
                        maior = notas[x][y];
                        System.out.println("está aprovado!");
                    }
                }
                //System.out.println(" - Menor nota: " + menor);
                
            }
    
        } catch(InputMismatchException e) {
            System.out.println("Erro de digitação!");
        }
        
    }
    
}
