﻿using Metodista.AlterarProdutos;
using Metodista.BancoDados;
using Metodista.ConsultarProdutos;
using Metodista.ExcluirProdutos;
using Metodista.IncluirProdutos;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metodista.Principal
{
    public partial class Frm_Principal : Form
    {
        // declarando os atributos
        private ConexaoBancoDados db = new ConexaoBancoDados();

        // construtor da classe
        public Frm_Principal(string usuario)
        {
            InitializeComponent();
        }

        // metodos da classe
        private void lblSair_Click(object sender, EventArgs e)
        {
            // fechando o banco de dados
            if (db.conn != null) { db.conn.Close(); db.conn = null; }
            // fechando a tela (form) principal
            Frm_Principal.ActiveForm.Close();
        }

        private void SMConsultarProduto_Click(object sender, EventArgs e)
        {
            // chamando o formulario Frm_ConsultarProdutos
            Frm_ConsultarProdutos consultarProdutos = new Frm_ConsultarProdutos();
            consultarProdutos.ShowDialog();
        }

        private void SMAlterarProduto_Click(object sender, EventArgs e)
        {
            // chamando a tela de alterar produto
            Frm_AlterarProduto alterarProduto = new Frm_AlterarProduto();
            alterarProduto.ShowDialog();
        }

        private void MCadastro_Click(object sender, EventArgs e)
        {

        }

        private void SMExcluirProduto_Click(object sender, EventArgs e)
        {
            // chamando a tela de excluir produto
            Frm_ExcluirProduto excluirProduto = new Frm_ExcluirProduto();
            excluirProduto.ShowDialog();
        }

        private void SMIncluirProduto_Click(object sender, EventArgs e)
        {
            Frm_AdicionarProduto incluirProduto = new Frm_AdicionarProduto();
            incluirProduto.ShowDialog();
        }
    }
}
